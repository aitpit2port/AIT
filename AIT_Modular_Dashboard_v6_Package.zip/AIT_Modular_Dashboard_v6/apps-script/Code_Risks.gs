// AIT Modular Dashboard v6 - risks page data wrapper
function getRisksPage_(payload) {
  return (payload && payload.risks) ? payload.risks : { no_data: true, message: 'No risks data found.' };
}
