// AIT Modular Dashboard v6 - expenses page data wrapper
function getExpensesPage_(payload) {
  return (payload && payload.expenses) ? payload.expenses : { no_data: true, message: 'No expenses data found.' };
}
