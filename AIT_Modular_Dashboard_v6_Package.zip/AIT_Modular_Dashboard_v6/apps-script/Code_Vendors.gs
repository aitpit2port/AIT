// AIT Modular Dashboard v6 - vendors page data wrapper
function getVendorsPage_(payload) {
  return (payload && payload.vendors) ? payload.vendors : { no_data: true, message: 'No vendors data found.' };
}
