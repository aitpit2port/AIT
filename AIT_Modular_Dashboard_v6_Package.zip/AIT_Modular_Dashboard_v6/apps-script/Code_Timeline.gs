// AIT Modular Dashboard v6 - timeline page data wrapper
function getTimelinePage_(payload) {
  return (payload && payload.timeline) ? payload.timeline : { no_data: true, message: 'No timeline data found.' };
}
