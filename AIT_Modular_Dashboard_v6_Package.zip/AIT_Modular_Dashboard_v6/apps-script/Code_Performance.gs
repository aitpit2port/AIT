// AIT Modular Dashboard v6 - performance page data wrapper
function getPerformancePage_(payload) {
  return (payload && payload.performance) ? payload.performance : { no_data: true, message: 'No performance data found.' };
}
