// ============================================================
// AIT Projects Dashboard — Master Backend (v4)
// ------------------------------------------------------------
// Builds on v3 (real-data-only). Changes in this version:
//   1. Project Timeline now reads REAL data from "Gantt Chart"
//      sheet in the Budget Model spreadsheet (WBS hierarchy,
//      task titles, owners, dates, % complete).
//   2. Production / Lots now reads REAL data from the "Lots"
//      sheet in Supply Chain (now populated — 15 real batches).
//   3. Equipment status (Active/Inactive/Off-Hire) is surfaced
//      on the Vendor & Procurement page as a real, honest signal
//      — NOT fabricated contract/performance ratings.
//   4. Removed all remaining fabricated/placeholder fields that
//      had no real source (budget waterfall chart data; fake
//      filter option lists like CAPEX/OPEX, Approved/Pending).
//   5. Risk Register and Approval Workflow remain `no_data: true`
//      — confirmed (after exhaustive review of all 3 source
//      spreadsheets) that no dedicated source sheet exists yet.
// ============================================================

const ID_EXPENSES  = '1qI__3TaCHBPV48NSt6oICMxY58Z8F73oZxpetGvIyNc';
const ID_SUPPLY    = '1h1HqsM7SDhMXsMBTde2KfuKOQ6OvIM3cpWDycHlBeXw';
const ID_BUDGET    = '1Z1xR8cvKwLWTeCqkbBHkB3PA1j9GAqjNXewMYavzq-I';
const ID_DASHBOARD = '1JflVq4oxhmxHUalVK2mzEy6ERTYnEfOi4iKyPq8dnO8';
const BACKEND_VERSION = 'v6-modular-pages-2026-06-23';

const PAGES = [
  'exec', 'timeline', 'budget', 'expenses', 'cost',
  'cashflow', 'risks', 'vendors', 'approvals', 'performance',
  'production', 'quality', 'mines'
];

// ============================================================
// JSON / JSONP RESPONSE HELPER
// ------------------------------------------------------------
// GitHub Pages cannot reliably read Apps Script JSON with fetch()
// because of browser CORS restrictions. JSONP fixes this for a
// static GitHub dashboard by returning: callback({...});
// If no callback is sent, the API still returns normal JSON.
// ============================================================
function jsonResponse_(e, obj) {
  const callback = e && e.parameter ? String(e.parameter.callback || '').trim() : '';
  const json = JSON.stringify(obj);

  if (callback && /^[A-Za-z_$][0-9A-Za-z_$\.]*$/.test(callback)) {
    return ContentService
      .createTextOutput(callback + '(' + json + ');')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }

  return ContentService
    .createTextOutput(json)
    .setMimeType(ContentService.MimeType.JSON);
}


// ============================================================
// CACHE AGE HELPER
// Returns how many minutes old the cached lastUpdated timestamp is,
// or null if the timestamp is missing / unparseable.
// ============================================================
function bool_(v) {
  if (v === true) return true;
  const x = String(v || '').trim().toLowerCase();
  return x === 'true' || x === 'yes' || x === 'y' || x === '1';
}

function getCacheAgeMinutes_(lastUpdatedStr) {
  if (!lastUpdatedStr) return null;
  try {
    // Format written by syncAll: "dd/MM/yyyy HH:mm" in Cairo TZ
    const parts = String(lastUpdatedStr).match(/(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2})/);
    if (!parts) return null;
    const d = new Date(parts[3], parts[2] - 1, parts[1], parts[4], parts[5]);
    if (isNaN(d.getTime())) return null;
    return (new Date() - d) / 60000;
  } catch (e) { return null; }
}
// ============================================================
// doGet
// ============================================================
function doGet(e) {
  try {
    const email  = e && e.parameter ? (e.parameter.email  || '') : '';
    const action = e && e.parameter ? (e.parameter.action || 'ping') : 'ping';

    if (action === 'ping') {
      return jsonResponse_(e, { ok: true, service: 'AIT Projects Dashboard API', version: BACKEND_VERSION, ts: new Date().toISOString(), note: 'Use action=checkAuth, data, or refresh with an authorized email.' });
    }

    if (action === 'checkAuth') {
      const pwd = e && e.parameter ? (e.parameter.password || '') : '';
      return jsonResponse_(e, checkPermissions(email, pwd));
    }

    if (action === 'getUsers') {
      const pwd3 = e && e.parameter ? (e.parameter.password || '') : '';
      const adminCheck = checkPermissions(email, pwd3);
      if (!adminCheck.active || String(adminCheck.role || '').toLowerCase() !== 'admin') {
        return jsonResponse_(e, { error: 'FORBIDDEN', message: 'Admin access required.' });
      }
      return jsonResponse_(e, getUsersList_());
    }

    if (action === 'saveUsers') {
      const pwd4   = e && e.parameter ? (e.parameter.password || '') : '';
      const usersJson = e && e.parameter ? (e.parameter.users || '[]') : '[]';
      const adminCheck2 = checkPermissions(email, pwd4);
      if (!adminCheck2.active || String(adminCheck2.role || '').toLowerCase() !== 'admin') {
        return jsonResponse_(e, { error: 'FORBIDDEN', message: 'Admin access required.' });
      }
      return jsonResponse_(e, saveUsersList_(usersJson));
    }


    if (action === 'page') {
      const pwdPage = e && e.parameter ? (e.parameter.password || '') : '';
      const page = normalizePageKey_(e && e.parameter ? (e.parameter.page || 'exec') : 'exec');
      const perms = checkPermissions(email, pwdPage);
      if (!perms.active) {
        return jsonResponse_(e, { error: 'ACCESS_DENIED', message: perms.message || 'Not authorized.' });
      }
      if (!userCanOpenPage_(perms, page)) {
        return jsonResponse_(e, { error: 'FORBIDDEN_PAGE', message: 'This user is not allowed to open page: ' + page, pageKey: page });
      }
      const data = readDashboardFromDb();
      const pageData = getPagePayload_(page, data);
      const result = {
        ok: true,
        pageKey: page,
        data: pageData,
        lastUpdated: data.lastUpdated,
        stats: data.stats,
        permissions: perms,
        meta: data.meta
      };
      result[page] = pageData;
      return jsonResponse_(e, result);
    }

    if (action === 'data' || action === 'refresh') {
      const pwd2 = e && e.parameter ? (e.parameter.password || '') : '';
      const perms = checkPermissions(email, pwd2);
      if (!perms.active) {
        return jsonResponse_(e, { error: 'ACCESS_DENIED', message: perms.message || 'Not authorized.' });
      }

      // Both 'data' and 'refresh' read live from source spreadsheets.
      // No caching, no stale data, no writing to Dashboard sheets.
      const data = readDashboardFromDb();
      const result = {
        lastUpdated: data.lastUpdated,
        stats: data.stats,
        permissions: perms,
        meta: data.meta
      };

      perms.pages.forEach(p => {
        if (data[p] !== undefined) result[p] = data[p];
      });

      return jsonResponse_(e, result);
    }

    return jsonResponse_(e, { error: 'UNKNOWN_ACTION' });
  } catch (err) {
    return jsonResponse_(e, { error: err.toString(), stack: err.stack });
  }
}

// ============================================================
// PERMISSIONS
// ============================================================
function checkPermissions(email, password) {
  if (!email) return { active: false, pages: [], role: 'none', message: 'No email provided.' };
  const ss = SpreadsheetApp.openById(ID_DASHBOARD);
  const sh = ss.getSheetByName('Permissions');
  if (!sh) return { active: false, pages: [], role: 'none', message: 'Permissions sheet not found.' };

  const data = sh.getDataRange().getValues();
  // Sheet columns: 0=Email, 1=Password, 2=Name, 3=Role, 4=Active, 5=Excel, 6=PDF, 7+=Pages
  const EMAIL_COL = 0, PASS_COL = 1, NAME_COL = 2, ROLE_COL = 3, ACTIVE_COL = 4, EXCEL_COL = 5, PDF_COL = 6, FIRST_PAGE = 7;

  for (let i = 2; i < data.length; i++) {
    const rowEmail = String(data[i][EMAIL_COL] || '').trim().toLowerCase();
    if (!rowEmail || rowEmail.indexOf('@') === -1) continue;
    if (rowEmail !== email.trim().toLowerCase()) continue;

    const active = bool_(data[i][ACTIVE_COL]);
    if (!active) return { active: false, pages: [], role: String(data[i][ROLE_COL]), message: 'Account suspended.' };

    // Password validation: if the sheet has a password, the user must enter the exact same password.
    const storedPass = String(data[i][PASS_COL] || '').trim();
    const givenPass  = String(password || '').trim();
    if (!storedPass) {
      return { active: false, pages: [], role: 'none', message: 'Password not set for this user.' };
    }
    if (storedPass !== givenPass) {
      return { active: false, pages: [], role: 'none', message: 'Incorrect password.' };
    }

    const canExcel = bool_(data[i][EXCEL_COL]);
    const canPdf   = bool_(data[i][PDF_COL]);

    const pages = [];
    PAGES.forEach((p, idx) => {
      const val = data[i][FIRST_PAGE + idx];
      if (bool_(val)) pages.push(p);
    });

    return { active: true, email: rowEmail, name: String(data[i][NAME_COL] || ''), role: String(data[i][ROLE_COL] || ''), pages, canExcel, canPdf };
  }
  return { active: false, pages: [], role: 'none', message: 'Email not registered.' };
}

// ============================================================
// TRIGGER ENTRY POINTS
// ============================================================
function manualSync() {
  const d = syncAll({ writeFacts: true });
  Logger.log('Sync OK | expenses:' + d.stats.expense_records + ' budget_lines:' + d.stats.budget_lines + ' mines:' + d.stats.mines + ' lots:' + d.stats.lots + ' gantt_tasks:' + d.stats.gantt_tasks);
}

function installTrigger() {
  // No background trigger needed — data is read live on every dashboard request.
  // This function is kept for compatibility but does nothing.
  Logger.log('No trigger installed — dashboard reads live from source on every request.');
}

// ============================================================
// CLEANUP — run ONCE to remove leftover/duplicate sheets
// ============================================================
function cleanupDashboardSheets() {
  const ss = SpreadsheetApp.openById(ID_DASHBOARD);
  const OLD_LOOKER_SHEETS = [
    'Executive Summary', 'Budget Overview', 'Expenses & Payments',
    'Cost Analysis', 'Cash Flow Forecast', 'Risk & Alerts',
    'Vendor & Procurement', 'Project Timeline', 'Monthly Performance',
    'Approval Workflow', 'README - Looker Studio',
  ];
  const DUPLICATE_FACT_SHEETS = ['Actual Spend', 'Total Budget'];
  const LEGACY_MISC_SHEETS = ['12'];
  const MISPLACED_SOURCE_SHEETS = ['Lots', 'samples'];

  const allToRemove = [...OLD_LOOKER_SHEETS, ...DUPLICATE_FACT_SHEETS, ...LEGACY_MISC_SHEETS];
  let removed = [], skipped = [];

  allToRemove.forEach(name => {
    const sh = ss.getSheetByName(name);
    if (sh) { ss.deleteSheet(sh); removed.push(name); }
    else skipped.push(name);
  });

  MISPLACED_SOURCE_SHEETS.forEach(name => {
    const sh = ss.getSheetByName(name);
    const factEquivalent = ss.getSheetByName(name === 'Lots' ? 'fact_lots' : 'fact_samples');
    if (sh && factEquivalent && factEquivalent.getLastRow() > 1) {
      ss.deleteSheet(sh);
      removed.push(name + ' (misplaced source copy — verified fact_* equivalent exists)');
    } else if (sh) {
      skipped.push(name + ' (kept — no fact_* equivalent found yet)');
    }
  });

  Logger.log('✅ Removed ' + removed.length + ' sheet(s): ' + removed.join(', '));
  if (skipped.length) Logger.log('⏭ Skipped: ' + skipped.join(', '));
}

// ============================================================
// HELPERS
// ============================================================
const TZ = () => Session.getScriptTimeZone();
function fmt(v)   { if (!v) return ''; if (v instanceof Date) return Utilities.formatDate(v, TZ(), 'yyyy-MM-dd'); return String(v).trim(); }
function fmtDT(v) { if (!v) return ''; if (v instanceof Date) return Utilities.formatDate(v, TZ(), 'yyyy-MM-dd HH:mm'); return String(v).trim(); }
function n(v)     { const f = parseFloat(v); return isNaN(f) ? 0 : f; }
function s(v)     { return String(v || '').trim(); }
function pct(v, d){ return parseFloat(((v || 0) * 100).toFixed(d || 1)); }

function getRows(ss, name, headerRow) {
  const sh = ss.getSheetByName(name);
  if (!sh) return { r: [] };
  const last = sh.getLastRow(), cols = sh.getLastColumn();
  if (last <= headerRow) return { r: [] };
  const d = sh.getRange(headerRow + 1, 1, last - headerRow, cols).getValues();
  return { r: d.filter(row => row.some(v => v !== '' && v !== null)) };
}

function fmtM_(v) {
  const a = Math.abs(v);
  const sign = v < 0 ? '-' : '';
  if (a >= 1e9) return sign + (a / 1e9).toFixed(2) + 'B';
  if (a >= 1e6) return sign + (a / 1e6).toFixed(2) + 'M';
  if (a >= 1e3) return sign + (a / 1e3).toFixed(0) + 'K';
  return sign + Math.round(a).toString();
}

// ============================================================
// READ SOURCE 1: AIT_Expenses (Report)
// ============================================================
function readExpensesData(ssE) {
  const { r: expR } = getRows(ssE, 'Actual_Expenses', 1);
  const expenses = expR.map(r => ({
    ts: fmtDT(r[0]), date: fmt(r[1]), paid_by: s(r[2]),
    item: s(r[3]), merchant: s(r[4]), amount: Math.abs(n(r[5])),
    method: s(r[6]), swypex: s(r[7]), project: s(r[8]),
    lender: s(r[9]), lender_amt: Math.abs(n(r[10])), notes: s(r[11]),
    invoice: s(r[12]), supplier: s(r[13]), month: s(r[14]),
    category: s(r[15]), summary: s(r[16]), sub: s(r[17]),
  })).filter(r => r.amount > 0 && r.date);

  const { r: budR } = getRows(ssE, 'Monthly Budget', 1);
  const budget = budR.map(r => ({
    project: s(r[0]), category: s(r[1]), item: s(r[2]),
    budget: n(r[3]), required: n(r[4]), paid: n(r[5]),
    from: fmt(r[6]), to: fmt(r[7]), due: fmt(r[8]),
    freq: s(r[9]), month: s(r[10]), method: s(r[11]),
    payee: s(r[12]), comments: s(r[13]), code: s(r[14]),
  })).filter(r => r.project && r.budget > 0);

  const { r: eqR } = getRows(ssE, 'Equipment', 1);
  const eqLog = eqR.map(r => ({
    date: fmt(r[0]), from: s(r[2]), to: s(r[3]),
    total_hrs: n(r[4]), deducted: n(r[5]), net_hrs: n(r[6]) || n(r[4]),
    equipment: s(r[7]), month: s(r[8]), rep: s(r[9]), status: s(r[10]),
  })).filter(r => r.date && r.equipment);

  // Equipment master — includes real Status field (Active/Inactive/Off-Hire)
  const { r: eqMR } = getRows(ssE, 'Equipment Data', 1);
  const eqMaster = eqMR.map(r => ({
    id: s(r[0]), type: s(r[1]), contractor: s(r[2]),
    contract_rate: n(r[3]), monthly: n(r[4]), daily: n(r[5]), hourly: n(r[6]),
    transport: n(r[7]), advance: n(r[8]),
    start: fmt(r[9]), end: fmt(r[10]), project: s(r[11]), status: s(r[12]),
  })).filter(r => r.id || r.type);

  const { r: conR } = getRows(ssE, 'Contractors_Master', 1);
  const contractors = conR.map(r => ({
    id: s(r[0]), name: s(r[1]), rep: s(r[2]), pos: s(r[3]),
    mobile: s(r[4]), address: s(r[5]), bank: s(r[8]), acct: s(r[9]), iban: s(r[10]),
  })).filter(r => r.name);

  const { r: xfR } = getRows(ssE, 'Account Transfers', 1);
  const transfers = xfR.map(r => ({
    date: fmt(r[0]), month: s(r[1]), project: s(r[2]),
    to: s(r[3]), amount: n(r[4]), remaining: n(r[5]), spent: n(r[6]),
  })).filter(r => r.amount);

  const cfSheet = ssE.getSheetByName('Cash Flow');
  const cashFlowPlan = [];
  let remainingBudgetTotal = 0;
  if (cfSheet) {
    const last = cfSheet.getLastRow();
    if (last > 1) {
      const data = cfSheet.getRange(2, 1, last - 1, 11).getValues();
      data.forEach((r, idx) => {
        if (r[0] !== '' && r[0] !== null && n(r[4]) > 0) {
          cashFlowPlan.push({
            month: idx === 0 ? s(r[0]) : fmt(r[0]),
            operating_out: n(r[1]), one_time: n(r[2]), maintenance: n(r[3]),
            total_out: n(r[4]), cumulative_out: n(r[5]), notes: s(r[6]),
          });
        }
        if (idx === 0) remainingBudgetTotal = n(r[10]);
      });
    }
  }

  return { expenses, budget, eqLog, eqMaster, contractors, transfers, cashFlowPlan, remainingBudgetTotal };
}

// ============================================================
// READ SOURCE 2: AIT_Supply_chain
// ============================================================
function readSupplyData(ssS) {
  // Read from "Map" sheet — this is the correct, complete mine registry.
  // (The older "Mines " sheet had inconsistent/duplicate names that did
  // not match the names used in Lots/samples. "Map" uses the same real
  // place names — Hurghada, Aswan, Aswan 2, Marsa Alam... — that Lots
  // and samples already use, so no fuzzy name-matching is needed.)
  const { r: mineR } = getRows(ssS, 'Map', 1);
  const mines = mineR.map(r => {
    // Col4=Longitude, Col5=Latitude — but validate to handle any swapped rows
    let rawLng = n(r[4]), rawLat = n(r[5]);
    // If lat looks like a longitude (>90 or <-90) and vice versa, swap them
    if (Math.abs(rawLat) > 90 && Math.abs(rawLng) <= 90) {
      const tmp = rawLat; rawLat = rawLng; rawLng = tmp;
    }
    // avg_fe from Map sheet is stored as fraction (0.55) → convert to %
    const avgFe = n(r[20]);
    return {
      created: fmtDT(r[2]), lng: rawLng, lat: rawLat,
      name: s(r[6]), code: s(r[7]), contact: s(r[8]), contact_phone: s(r[9]),
      owner: s(r[10]), owner_phone: s(r[11]), gov: s(r[12]), region: s(r[13]),
      material: s(r[14]), status: s(r[15]), contract: s(r[16]),
      qty_ton: n(r[17]),
      fe_from: n(r[18]) > 1 ? n(r[18]) : parseFloat((n(r[18]) * 100).toFixed(1)),
      fe_to:   n(r[19]) > 1 ? n(r[19]) : parseFloat((n(r[19]) * 100).toFixed(1)),
      avg_fe:  avgFe > 1 ? avgFe : parseFloat((avgFe * 100).toFixed(1)),
      port: s(r[22]),
    };
  }).filter(r => r.name && (r.lng || r.lat));

  // Lots — NOW POPULATED with real data. Column layout (current real sheet):
  // 0=Last Update  1=Mine_Name  2=Sub Zone Name Batch  3=batch  4=Quantity(Ton)  5=Volume(m³)  6=AVG Fe
  const { r: lotR } = getRows(ssS, 'Lots', 1);
  // Lots: avg_fe is stored as fraction (0.55) in the sheet — convert to % for
  // consistency with the samples sheet where Fe is stored as % (56.3).
  const lots = lotR.map(r => ({
    updated: fmtDT(r[0]), mine: s(r[1]), zone: s(r[2]),
    batch: s(r[3]), qty_ton: n(r[4]), volume: n(r[5]),
    avg_fe: n(r[6]) > 1 ? n(r[6]) : parseFloat((n(r[6]) * 100).toFixed(2)),
  })).filter(r => r.mine && r.batch);

  // Full XRF chemical element/oxide column map (samples sheet, header row 1).
  // We read ALL of them — buildDashboardData() will later detect which
  // ones actually have non-zero data and only expose those for the
  // dashboard's element trend chart (no point listing 23 elements that
  // were never measured).
  // ── UPDATED column map for current samples sheet layout ──────────────────
  // Sheet columns (0-indexed, from actual AIT_Supply_chain workbook):
  //   0=created_by  1=date  2=mine_name  3=material_type
  //   4=zone_batch  5=batch  6-15=subzone_1..10  16=subzone_path
  //   17=Fe  18=Ca  19=Mn  20=LE  21=Sr  22=Zr  23=Zn  24=Co  25=Ti
  //   26=Sb  27=Cu  28=L.O.I  29=Al2O3  30=Pb  31=Ni  32=V  33=As
  //   34=Cd  35=CaO  36=Cl  37=Cr  38=FE2O3  39=MgO  40=MnO  41=Moisture
  //   42=Mo  43=Nb  44=P2O5  45=K2O  46=Rh  47=SiO2  48=Na2O  49=SU
  //   50=SO3  51=Sn  52=TiO2  53=W  54=analysis_type
  // Fe is stored as PERCENTAGE (0–100), not fraction (0–1).
  const ELEMENT_COLS = {
    17:'Fe', 18:'Ca', 19:'Mn', 20:'LE', 21:'Sr', 22:'Zr', 23:'Zn', 24:'Co',
    25:'Ti', 26:'Sb', 27:'Cu', 28:'LOI', 29:'Al2O3', 30:'Pb', 31:'Ni', 32:'V',
    33:'As', 34:'Cd', 35:'CaO', 36:'Cl', 37:'Cr', 38:'Fe2O3', 39:'MgO', 40:'MnO',
    41:'Moisture', 42:'Mo', 43:'Nb', 44:'P2O5', 45:'K2O', 46:'Rh', 47:'SiO2',
    48:'Na2O', 49:'SU', 50:'SO3', 51:'Sn', 52:'TiO2', 53:'W',
  };
  const ELEMENT_NAMES = Object.values(ELEMENT_COLS);

  const { r: samR } = getRows(ssS, 'samples', 1);
  const samples = samR.map(r => {
    // New layout: r[1]=date, r[2]=mine_name, r[3]=material_type,
    //             r[4]=zone_batch, r[5]=batch
    const row = {
      date:     fmtDT(r[1]),
      mine:     s(r[2]),
      material: s(r[3]),
      zone:     s(r[4]),
      batch:    s(r[5]),
    };
    ELEMENT_NAMES.forEach((name, idx) => {
      const colIdx = parseInt(Object.keys(ELEMENT_COLS)[idx]);
      row[name] = n(r[colIdx]);
    });
    return row;
  }).filter(r => r.mine && r.batch && r.Fe > 0); // exclude rows with no real Fe% reading

  return { mines, lots, samples, elementNames: ELEMENT_NAMES };
}

// ============================================================
// READ SOURCE 3: AIT_Budget_Detailed_Model
// ============================================================
function readBudgetModel(ssB) {
  const { r: kpiR } = getRows(ssB, 'Management Summary', 1);
  const budgetModel = {};
  kpiR.forEach(r => {
    const metric = s(r[1]), unit = s(r[2]), value = r[4], category = s(r[6]);
    if (metric && value !== null && value !== '') budgetModel[metric] = { value, unit, category };
  });
  return budgetModel;
}

// ============================================================
// READ GANTT CHART (real Project Timeline source)
// ------------------------------------------------------------
// Layout in "Gantt Chart" sheet of the Budget Model spreadsheet:
//   Header row = 6 (1-indexed): WBS | Task Title | Owner | Start | Due | Duration | % Complete
//   Top-level tasks have a real WBS number (e.g. "1.0", "2.1").
//   Sub-tasks under a top-level task often show WBS = TRUE (a
//   boolean leftover from an Excel checkbox/autofill) instead of
//   a real WBS code — we synthesize a child WBS (e.g. "1.1.a",
//   "1.1.b") based on the nearest preceding real WBS number so
//   every row still gets a stable, sortable identifier.
// ============================================================
function readGanttChart(ssB) {
  const sh = ssB.getSheetByName('Gantt Chart');
  if (!sh) return { tasks: [], found: false };

  const lastRow = sh.getLastRow();
  if (lastRow < 11) return { tasks: [], found: false };

  // Columns B..H (2..8) hold WBS, Title, Owner, Start, Due, Duration, %Complete
  const data = sh.getRange(11, 2, lastRow - 10, 7).getValues();

  // IMPORTANT: Excel stores most WBS numbers (1.0, 1.1, 2.3...) as actual
  // numbers (type "number" in Apps Script), not strings. Sub-tasks that
  // have no WBS code show up as the boolean TRUE (an Excel checkbox/
  // autofill leftover) — these must NOT be mistaken for a real WBS.
  // A few deep sub-tasks (e.g. "1.1.1", "3.2.1") ARE already strings.
  function isRealWbs(v) {
    if (typeof v === 'boolean') return false; // TRUE/FALSE placeholders are not WBS codes
    if (typeof v === 'number') return true;   // 1.0, 2.1, etc. stored as numbers
    if (typeof v === 'string' && /^\d+(\.\d+)*$/.test(v.trim())) return true;
    return false;
  }
  function wbsToString(v) {
    if (typeof v === 'number') {
      // 1 -> "1.0", 1.1 -> "1.1" (preserve the one-decimal convention used in the sheet)
      return (Math.floor(v) === v) ? v.toFixed(1) : String(v);
    }
    return String(v).trim();
  }

  const tasks = [];
  let lastRealWbs = '';
  let subIndex = 0;

  data.forEach(row => {
    const [wbsRaw, title, owner, start, due, duration, pctRaw] = row;
    if (!title) return; // skip fully blank rows

    let wbs;
    if (isRealWbs(wbsRaw)) {
      wbs = wbsToString(wbsRaw);
      lastRealWbs = wbs;
      subIndex = 0;
    } else {
      // Synthesize a stable child id under the last real WBS seen
      subIndex++;
      wbs = lastRealWbs ? (lastRealWbs + '.' + subIndex) : ('?.' + subIndex);
    }

    const level = (wbs.match(/\./g) || []).length <= 1 ? 0 : 1;
    const pct = n(pctRaw); // already a 0..1 fraction in the sheet
    const pctClamped = Math.max(0, Math.min(1, pct));

    let status = 'Planned';
    if (pctClamped >= 0.999) status = 'Completed';
    else if (pctClamped > 0) status = 'In Progress';

    // Delay: if due date is in the past and task isn't complete, flag delayed
    let delayDays = 0;
    try {
      if (due && pctClamped < 0.999) {
        const dueDate = new Date(due);
        const today = new Date();
        const diffDays = Math.ceil((today - dueDate) / 86400000);
        if (diffDays > 0) { delayDays = diffDays; status = 'Delayed'; }
      }
    } catch (e) { /* ignore bad dates */ }

    tasks.push({
      wbs: wbs,
      title: s(title),
      owner: s(owner) || 'Unassigned',
      level: level,
      start: fmt(start),
      due: fmt(due),
      duration: n(duration),
      complete: Math.round(pctClamped * 100),
      status: status,
      delay: delayDays,
    });
  });

  return { tasks, found: tasks.length > 0 };
}

// ============================================================
// CATEGORY MAPPING (unchanged from v3 — verified 100% reconciled)
// ============================================================
function normItem(x) { return String(x || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, ' ').trim(); }

const KEYWORD_CATEGORY_MAP = [
  [['maintenance', 'tools', 'spare', 'repair'], 'Maintenance'],
  [['fuel', 'gasoline', 'petrol', 'diesel', 'hydraulic oil'], 'Fuel Expense'],
  [['labor', 'helper', 'worker'], 'Manpower'],
  [['water'], 'Utilities'],
  [['electricity', 'internet'], 'Utilities'],
  [['transport', 'vehicle', 'tires', 'wash', 'tricycle', 'crane'], 'Transportation'],
  [['safety', 'ppe', 'first aid', 'hse'], 'HSE'],
  [['rent', 'accommodation', 'camp'], 'Accommodation'],
  [['security'], 'Security Services'],
  [['grader', 'loader', 'excavator', 'crusher', 'engineering'], 'Equipment Leasing'],
  [['cleaning', 'stationery', 'printing', 'hospitality', 'brokerage', 'plumbing'], 'Site Services'],
];
function keywordCategory(text) {
  for (const [keywords, cat] of KEYWORD_CATEGORY_MAP) {
    if (keywords.some(kw => text.indexOf(kw) !== -1)) return cat;
  }
  return null;
}

function resolveExpenseCategories(expenses, budget) {
  const itemToCategory = {};
  budget.forEach(r => { if (r.item) itemToCategory[normItem(r.item)] = r.category; });

  expenses.forEach(r => {
    const key = normItem(r.summary) || normItem(r.item);
    let cat = itemToCategory[key] || null;
    if (!cat && key) {
      const found = Object.keys(itemToCategory).find(k => k.indexOf(key) !== -1 || key.indexOf(k) !== -1);
      if (found) cat = itemToCategory[found];
    }
    if (!cat) cat = keywordCategory(key + ' ' + normItem(r.sub));
    r.budget_category = cat || 'Other / Unmapped';
  });
}

// ============================================================
// MAIN SYNC
// ============================================================
function syncAll(options) {
  options = options || {};
  const writeFacts = options.writeFacts === true;
  const ssE = SpreadsheetApp.openById(ID_EXPENSES);
  const ssS = SpreadsheetApp.openById(ID_SUPPLY);
  const ssB = SpreadsheetApp.openById(ID_BUDGET);
  // Dashboard spreadsheet is only written when manualSync() is explicitly run.

  const { expenses, budget, eqLog, eqMaster, contractors, transfers, cashFlowPlan, remainingBudgetTotal } = readExpensesData(ssE);
  const { mines, lots, samples, elementNames } = readSupplyData(ssS);
  const budgetModel = readBudgetModel(ssB);
  const { tasks: ganttTasks, found: ganttFound } = readGanttChart(ssB);

  resolveExpenseCategories(expenses, budget);

  // ── CORE TOTALS ──────────────────────────────────────────
  const totBudget  = budget.reduce((a, r) => a + r.budget, 0);
  const totActual  = expenses.reduce((a, r) => a + r.amount, 0);
  const totPaid    = budget.reduce((a, r) => a + r.paid, 0);
  const totReq     = budget.reduce((a, r) => a + r.required, 0);
  const totPending = Math.max(totReq - totPaid, 0);
  const util       = totBudget > 0 ? totActual / totBudget : 0;
  const overBudget = Math.max(totActual - totBudget, 0);
  const now        = new Date();
  const projects   = [...new Set(budget.map(r => r.project).filter(Boolean))];

  // ── Budget by category ───────────────────────────────────
  const catMap = {};
  budget.forEach(r => {
    if (!catMap[r.category]) catMap[r.category] = { category: r.category, budget: 0, actual: 0, required: 0, paid: 0 };
    catMap[r.category].budget += r.budget; catMap[r.category].required += r.required; catMap[r.category].paid += r.paid;
  });
  expenses.forEach(r => {
    const cat = r.budget_category;
    if (!catMap[cat]) catMap[cat] = { category: cat, budget: 0, actual: 0, required: 0, paid: 0 };
    catMap[cat].actual += r.amount;
  });
  const budgetCats = Object.values(catMap).map(c => ({
    ...c, variance: c.budget - c.actual, remaining: c.budget - c.actual,
    util: c.budget > 0 ? parseFloat((c.actual / c.budget * 100).toFixed(1)) : 0,
    status: c.budget === 0 ? 'Unbudgeted' : (c.actual > c.budget ? 'Over Budget' : (c.actual / c.budget > 0.9 ? 'At Risk' : 'On Track')),
  })).sort((a, b) => b.budget - a.budget);

  // ── Monthly trend ─────────────────────────────────────────
  const mMap = {};
  expenses.forEach(r => {
    const m = r.month || r.date.substring(0, 7) || 'Unknown';
    if (!mMap[m]) mMap[m] = { month: m, actual: 0, paid: 0, pending: 0 };
    mMap[m].actual += r.amount;
  });
  budget.forEach(r => {
    const m = r.month || '';
    if (m) { if (!mMap[m]) mMap[m] = { month: m, actual: 0, paid: 0, pending: 0 }; mMap[m].paid += r.paid; mMap[m].pending += Math.max(r.required - r.paid, 0); }
  });
  const monthOrder = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const monthlyTrend = Object.values(mMap).sort((a, b) => monthOrder.indexOf(a.month) - monthOrder.indexOf(b.month));

  // ── Top vendors ───────────────────────────────────────────
  const vMap = {};
  expenses.forEach(r => {
    const v = r.supplier || r.merchant || '';
    if (!v) return;
    if (!vMap[v]) vMap[v] = { name: v, category: r.budget_category || r.sub || 'Other', commitments: 0, paid: 0, count: 0 };
    vMap[v].commitments += r.amount; vMap[v].paid += r.amount; vMap[v].count++;
  });
  const topVendors = Object.values(vMap).sort((a, b) => b.commitments - a.commitments).slice(0, 10)
    .map(v => ({ ...v, balance: 0, pct: 1 }));

  // ── Expense distribution ──────────────────────────────────
  const catSpend = {};
  expenses.forEach(r => { const cat = r.budget_category || 'Other / Unmapped'; catSpend[cat] = (catSpend[cat] || 0) + r.amount; });
  const expenseDist = Object.entries(catSpend)
    .map(([category, amount]) => ({ category, amount, pct: totActual > 0 ? parseFloat((amount / totActual * 100).toFixed(1)) : 0 }))
    .sort((a, b) => b.amount - a.amount);

  const costCenters = {};
  expenses.forEach(r => { const cc = r.sub || r.summary || 'Other'; costCenters[cc] = (costCenters[cc] || 0) + r.amount; });

  const payMethods = {};
  expenses.forEach(r => { payMethods[r.method || 'Other'] = (payMethods[r.method || 'Other'] || 0) + r.amount; });

  // ── Alerts (real, derived) ────────────────────────────────
  const alerts = [];
  budgetCats.filter(c => c.budget > 0 && c.actual > c.budget).forEach(c => {
    const p = ((c.actual - c.budget) / c.budget * 100).toFixed(1);
    alerts.push({ type: 'Over Budget', category: c.category, project: 'All', issue: 'Expenses exceeded budget by ' + p + '%', date: fmt(now), amount: c.actual - c.budget, severity: 'Critical', status: 'Open' });
  });
  budget.filter(r => r.required > r.paid && r.due).forEach(r => {
    try {
      const d = new Date(r.due);
      const days = Math.ceil((d - now) / 86400000);
      if (days <= 7 && days >= 0) alerts.push({ type: 'Upcoming Payment', category: r.category, project: r.project, issue: 'Payment due within ' + days + ' days', date: r.due, amount: r.required - r.paid, severity: 'High', status: 'Pending' });
      if (days < 0) alerts.push({ type: 'Delayed Payment', category: r.category, project: r.project, issue: 'Payment is overdue', date: r.due, amount: r.required - r.paid, severity: 'Medium', status: 'Overdue' });
    } catch (e) { /* skip bad date */ }
  });
  expenses.filter(r => !r.invoice || r.invoice === 'بدون فاتورة')
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 10)
    .forEach(r => {
      alerts.push({ type: 'Document Missing', category: r.budget_category, project: r.project, issue: 'Supporting document not attached', date: r.date, amount: r.amount, severity: 'Low', status: 'Open' });
    });

  // ── Cost details ──────────────────────────────────────────
  const costMap = {};
  expenses.forEach(r => {
    const cat = r.budget_category || 'Other / Unmapped';
    const k = cat + '|' + (r.summary || r.item || '—');
    if (!costMap[k]) costMap[k] = { category: cat, item: r.summary || r.item, center: r.sub || cat, vendor: r.supplier || r.merchant, actual: 0, budget: 0 };
    costMap[k].actual += r.amount; costMap[k].vendor = r.supplier || r.merchant || costMap[k].vendor;
  });
  budget.forEach(r => { const k = r.category + '|' + r.item; if (costMap[k]) costMap[k].budget = r.budget; });
  const costDetails = Object.values(costMap).map(r => ({
    ...r, variance: r.actual - r.budget,
    var_pct: r.budget > 0 ? parseFloat(((r.actual - r.budget) / r.budget * 100).toFixed(1)) : 0,
    status: r.budget === 0 ? 'Unbudgeted' : (r.actual > r.budget ? 'Over Budget' : (Math.abs((r.actual - r.budget) / r.budget) < 0.05 ? 'On Track' : 'Under Budget')),
  })).sort((a, b) => b.actual - a.actual);

  const top10 = [...expenses].sort((a, b) => b.amount - a.amount).slice(0, 10)
    .map(r => ({ item: r.summary || r.item, spend: r.amount, category: r.budget_category || 'Other' }));

  const paretoTotal = top10.reduce((s2, r) => s2 + r.spend, 0);
  let cum = 0;
  const pareto = top10.map(r => { cum += r.spend; return { item: r.item, spend: r.spend, cum_pct: paretoTotal > 0 ? parseFloat((cum / paretoTotal * 100).toFixed(1)) : 0 }; });

  const topCats = budgetCats.slice(0, 5).map(c => c.category);
  const heatMonths = monthlyTrend.map(m => m.month);
  const heatmap = topCats.map(cat => {
    const row = { category: cat };
    heatMonths.forEach(m => {
      row[m] = expenses.filter(e => e.budget_category === cat && (e.month === m || e.date.substring(0, 7) === m)).reduce((s2, e) => s2 + e.amount, 0);
    });
    return row;
  });

  const eqHours = {};
  eqLog.forEach(r => {
    if (!eqHours[r.equipment]) eqHours[r.equipment] = { type: r.equipment, total_hrs: 0 };
    eqHours[r.equipment].total_hrs += r.net_hrs;
  });

  // ── CASH FLOW ─────────────────────────────────────────────
  const totalTransfersIn = transfers.reduce((s2, r) => s2 + r.amount, 0);
  const forecastCashOut  = cashFlowPlan.length ? cashFlowPlan[cashFlowPlan.length - 1].cumulative_out : totActual;
  const cashFlowPlanTotal = remainingBudgetTotal || forecastCashOut;

  const cf6m = cashFlowPlan.map(r => ({
    month: r.month,
    cash_out: Math.round(r.total_out),
    cumulative_out: Math.round(r.cumulative_out),
    operating_out: Math.round(r.operating_out),
    one_time: Math.round(r.one_time),
    maintenance: Math.round(r.maintenance),
    notes: r.notes,
  }));

  const cashOutByCat = budgetCats.filter(c => c.actual > 0).slice(0, 8).map(c => ({ category: c.category, amount: c.actual }));

  const upcomingPayments = budget.filter(r => r.required > r.paid && r.due).map(r => {
    try {
      const due = new Date(r.due);
      const days = Math.ceil((due - now) / 86400000);
      return { due: r.due, payee: r.payee || r.category, project: r.project, category: r.category, amount: r.required - r.paid, days, status: days < 0 ? 'Overdue' : days <= 7 ? 'High' : days <= 14 ? 'Medium' : 'Low' };
    } catch (e) { return null; }
  }).filter(r => r).sort((a, b) => a.days - b.days);

  // Normalize material to Title Case at the point of reading mines, so
  // that regardless of how it is stored in the source sheet (lowercase
  // "hematite" or uppercase "Hematite"), the value is always consistent
  // throughout the payload, fact_samples, and filter dropdowns.
  function titleCase(str) { return str ? str.charAt(0).toUpperCase() + str.slice(1).toLowerCase() : str; }

  // Build a simple exact-match lookup (normalized to lowercase key → TitleCase value)
  function normMineName(x) { return String(x || '').toLowerCase().trim().replace(/\s+/g, ' '); }
  const mineToMaterial = {};
  mines.forEach(m => { if (m.name) mineToMaterial[normMineName(m.name)] = titleCase(m.material) || 'Unknown'; });

  function materialFor(mineName) {
    const key = normMineName(mineName);
    return { material: mineToMaterial[key] || 'Unknown', matchMethod: mineToMaterial[key] ? 'exact' : 'no-match' };
  }

  // Attach material type + match status directly onto each sample and lot record
  // For samples: material_type column (col3) is already in r.material from the new sheet layout.
  // We still run materialFor() as a fallback/override for rows where col3 is blank.
  samples.forEach(r => {
    if (!r.material || r.material === '' || r.material === 'Unknown') {
      const match = materialFor(r.mine);
      r.material = match.material;
      r.material_match = match.matchMethod;
    } else {
      // Normalize material from sheet (e.g. "Magnetite" → TitleCase)
      r.material = titleCase(r.material);
      r.material_match = 'sheet'; // sourced directly from the samples sheet
    }
  });
  lots.forEach(r => {
    const match = materialFor(r.mine);
    r.material = match.material;
    r.material_match = match.matchMethod;
  });

  const allMaterialTypes = [...new Set(mines.map(m => titleCase(m.material)).filter(Boolean))];

  // ── Fe% Pass/Reject thresholds — applied at outer scope so that
  // BOTH the quality payload AND fact_samples writer share the same
  // graded data (no duplication, no inconsistency). ────────────────
  const FE_THRESHOLD_MAP = { hematite: 55, limonite: 55, magnetite: 37 };
  function gradeOf(materialRaw, fe) {
    const key = String(materialRaw || '').toLowerCase();
    const threshold = FE_THRESHOLD_MAP[key];
    if (threshold === undefined) return 'ungraded';
    return fe >= threshold ? 'pass' : 'reject';
  }
  // Attach grade + threshold to every sample NOW so they appear in fact_samples
  samples.forEach(r => {
    r.grade = gradeOf(r.material, r.Fe);
    r.threshold = FE_THRESHOLD_MAP[String(r.material || '').toLowerCase()] || null;
  });

  // ── PRODUCTION / LOTS (now real — Lots sheet populated) ─────
  const byMine = (() => {
    const m = {};
    lots.forEach(r => {
      if (!m[r.mine]) m[r.mine] = { mine: r.mine, material: r.material, material_match: r.material_match, qty_ton: 0, avg_fe: 0, count: 0 };
      m[r.mine].qty_ton += r.qty_ton; m[r.mine].avg_fe += r.avg_fe; m[r.mine].count++;
    });
    return Object.values(m).map(r => ({ ...r, avg_fe: r.count > 0 ? parseFloat((r.avg_fe / r.count).toFixed(2)) : 0 }))
      .sort((a, b) => b.qty_ton - a.qty_ton);
  })();

  const samplesByMine = (() => {
    const m = {};
    samples.forEach(r => {
      if (!m[r.mine]) m[r.mine] = { mine: r.mine, material: r.material, material_match: r.material_match, avg_fe: 0, avg_al2o3: 0, count: 0 };
      m[r.mine].avg_fe += r.Fe; m[r.mine].avg_al2o3 += r.Al2O3; m[r.mine].count++;
    });
    return Object.values(m).map(r => ({ ...r, avg_fe: parseFloat((r.avg_fe / r.count).toFixed(2)), avg_al2o3: parseFloat((r.avg_al2o3 / r.count).toFixed(2)) }));
  })();

  // ── AVAILABLE ELEMENTS — only elements with at least one real
  // (non-zero) reading across all samples are surfaced to the
  // dashboard. This is computed dynamically so that once a lab
  // starts reporting a new element (e.g. SiO2), it appears in the
  // filter automatically with zero code changes here. ──────────
  const availableElements = elementNames.filter(name =>
    samples.some(r => (r[name] || 0) > 0)
  );

  // ── DAILY ELEMENT TREND — one row per sample date, one column
  // per available element, averaged across all samples on that
  // date. This feeds the multi-select line chart so the user can
  // pick any combination of elements and see "how were we doing
  // day by day" over a date range (the date range filter itself
  // is applied client-side in the dashboard, since this series
  // covers the full history). ──────────────────────────────────
  const elementTrendByDate = (() => {
    const byDate = {};
    samples.forEach(r => {
      const d = (r.date || '').substring(0, 10); // YYYY-MM-DD
      if (!d) return;
      if (!byDate[d]) {
        byDate[d] = { date: d, count: 0 };
        availableElements.forEach(el => { byDate[d][el] = 0; });
      }
      byDate[d].count++;
      availableElements.forEach(el => { byDate[d][el] += (r[el] || 0); });
    });
    return Object.values(byDate)
      .map(row => {
        const out = { date: row.date };
        availableElements.forEach(el => { out[el] = row.count > 0 ? parseFloat((row[el] / row.count).toFixed(3)) : 0; });
        return out;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  })();

  // ── VENDOR — real equipment operational status (not contract ratings) ──
  const eqStatusCounts = {};
  eqMaster.forEach(r => {
    const st = r.status || 'Unknown';
    eqStatusCounts[st] = (eqStatusCounts[st] || 0) + 1;
  });

  // ── TIMELINE KPIs (computed from real Gantt tasks) ────────
  const tlKpis = ganttFound ? (() => {
    const total = ganttTasks.length;
    const completed = ganttTasks.filter(t => t.status === 'Completed').length;
    const inProgress = ganttTasks.filter(t => t.status === 'In Progress').length;
    const delayed = ganttTasks.filter(t => t.status === 'Delayed').length;
    const planned = ganttTasks.filter(t => t.status === 'Planned').length;
    const topLevel = ganttTasks.filter(t => t.level === 0);
    const overallComplete = topLevel.length > 0 ? Math.round(topLevel.reduce((s2, t) => s2 + t.complete, 0) / topLevel.length) : 0;
    return {
      total, completed, inProgress, delayed, planned, overallComplete,
      byStatus: { Completed: completed, 'In Progress': inProgress, Delayed: delayed, Planned: planned },
    };
  })() : null;

  // ============================================================
  // FINAL PAGE-BY-PAGE PAYLOAD
  // ============================================================
  const payload = {

    // ── PAGE 1: EXECUTIVE SUMMARY ──────────────────────────
    exec: {
      kpis: [
        { key: 'total_budget', label: 'TOTAL BUDGET',      value: totBudget,           fmt: 'currency' },
        { key: 'actual_spend', label: 'ACTUAL SPEND',       value: totActual,           fmt: 'currency' },
        { key: 'remaining',    label: 'REMAINING BUDGET',   value: totBudget - totActual, fmt: 'currency', note: pct(1 - util) + '% Remaining' },
        { key: 'over_budget',  label: 'OVER BUDGET',        value: overBudget,          fmt: 'currency', note: totBudget > 0 ? pct(overBudget / totBudget) + '% of Budget' : '' },
        { key: 'paid_to_date', label: 'PAID TO DATE',       value: totPaid,             fmt: 'currency', note: totReq > 0 ? pct(totPaid / totReq) + '% of Required' : '' },
        { key: 'pending',      label: 'PENDING PAYMENTS',   value: totPending,          fmt: 'currency', note: totReq > 0 ? pct(totPending / totReq) + '% of Required' : '' },
        { key: 'util_pct',     label: 'BUDGET UTILIZATION', value: pct(util),           fmt: 'percent' },
        { key: 'alerts_count', label: 'OVERDUE / ALERTS',   value: alerts.length,       fmt: 'number', note: 'Items' },
      ],
      budget_vs_actual: budgetCats.map(c => ({ category: c.category, budget: c.budget, actual: c.actual })),
      expense_dist: expenseDist,
      monthly_trend: monthlyTrend,
      paid_vs_pending: monthlyTrend.map(m => ({ month: m.month, paid: m.paid, pending: m.pending })),
      util_by_cat: budgetCats.map(c => ({ category: c.category, util: c.util, status: c.status })),
      top_cost_centers: Object.entries(costCenters).map(([center, amount]) => ({ center, amount })).sort((a, b) => b.amount - a.amount).slice(0, 5),
      top_vendors: topVendors.slice(0, 5),
      alerts: alerts.slice(0, 8),
      projects,
      budget_progress_pct: pct(util),
    },

    // ── PAGE 2: PROJECT TIMELINE — NOW REAL (Gantt Chart sheet) ──
    timeline: ganttFound ? {
      no_data: false,
      kpis: [
        { label: 'TOTAL TASKS',         value: tlKpis.total,           fmt: 'number' },
        { label: 'COMPLETED',           value: tlKpis.completed,       fmt: 'number', note: tlKpis.total > 0 ? pct(tlKpis.completed / tlKpis.total) + '%' : '' },
        { label: 'IN PROGRESS',         value: tlKpis.inProgress,      fmt: 'number', note: tlKpis.total > 0 ? pct(tlKpis.inProgress / tlKpis.total) + '%' : '' },
        { label: 'DELAYED',             value: tlKpis.delayed,         fmt: 'number', note: tlKpis.total > 0 ? pct(tlKpis.delayed / tlKpis.total) + '%' : '' },
        { label: 'PLANNED',             value: tlKpis.planned,         fmt: 'number', note: tlKpis.total > 0 ? pct(tlKpis.planned / tlKpis.total) + '%' : '' },
        { label: 'OVERALL COMPLETION',  value: tlKpis.overallComplete, fmt: 'percent', note: 'Top-level phases' },
      ],
      by_status: tlKpis.byStatus,
      by_owner: (() => {
        const m = {};
        ganttTasks.forEach(t => { m[t.owner] = (m[t.owner] || 0) + 1; });
        return Object.entries(m).map(([owner, count]) => ({ owner, count })).sort((a, b) => b.count - a.count);
      })(),
      gantt: ganttTasks.filter(t => t.level === 0).map(t => ({ wbs: t.wbs, phase: t.title, start: t.start, end: t.due, status: t.status })),
      tasks: ganttTasks,
      milestones: [], // no dedicated milestone flag in the source sheet — left empty rather than fabricated
      source_note: 'Read from "Gantt Chart" sheet in the Budget Model spreadsheet.',
    } : {
      no_data: true,
      message: 'No task/Gantt source sheet found yet. Add a sheet with task, phase, owner, start/end date, % complete, status to populate this page.',
      kpis: [], by_status: {}, by_owner: [], milestones: [], gantt: [], tasks: [],
    },

    // ── PAGE 3: BUDGET OVERVIEW ─────────────────────────────
    budget: {
      kpis: [
        { label: 'TOTAL BUDGET',       value: totBudget,            fmt: 'currency' },
        { label: 'ACTUAL SPEND',       value: totActual,            fmt: 'currency' },
        { label: 'REMAINING BUDGET',   value: totBudget - totActual, fmt: 'currency' },
        { label: 'BUDGET VARIANCE',    value: totActual - totBudget, fmt: 'currency' },
        { label: 'BUDGET UTILIZATION', value: pct(util),            fmt: 'percent', note: 'of Total Budget' },
        { label: 'OVER BUDGET ITEMS',  value: budgetCats.filter(c => c.budget > 0 && c.actual > c.budget).length, fmt: 'number', note: 'Items' },
      ],
      by_category: budgetCats,
      allocation_pct: budgetCats.map(c => ({ category: c.category, pct: totBudget > 0 ? parseFloat((c.budget / totBudget * 100).toFixed(1)) : 0 })),
      by_project: projects.map(p => {
        const pb = budget.filter(b => b.project === p);
        const pe = expenses.filter(e => e.project === p);
        const pBud = pb.reduce((s2, r) => s2 + r.budget, 0);
        const pAct = pe.reduce((s2, r) => s2 + r.amount, 0);
        return { project: p, budget: pBud, actual: pAct, variance: pAct - pBud };
      }),
      notes: [
        { icon: 'critical', text: 'Total actual spend is ' + pct(util) + '% of the total budget.' },
        { icon: 'warning', text: budgetCats.filter(c => c.budget > 0 && c.actual > c.budget).length + ' categories are currently over budget.' },
        { icon: 'chart', text: budgetCats[0] ? (budgetCats[0].category + ' represents ' + (totBudget > 0 ? pct(budgetCats[0].budget / totBudget) : 0) + '% of total budget allocation.') : '' },
      ],
    },

    // ── PAGE 4: EXPENSES & PAYMENTS ──────────────────────────
    expenses: {
      kpis: [
        { label: 'PAID TO DATE',       value: totPaid,    fmt: 'currency', note: totReq > 0 ? pct(totPaid / totReq) + '% of Required' : '' },
        { label: 'PENDING PAYMENTS',   value: totPending, fmt: 'currency', note: totReq > 0 ? pct(totPending / totReq) + '% of Required' : '' },
        { label: 'TOTAL TRANSACTIONS', value: expenses.length, fmt: 'number', note: 'Records' },
        { label: 'TOTAL BUDGET LINES', value: budget.length, fmt: 'number' },
      ],
      monthly_trend: monthlyTrend,
      paid_vs_pending: monthlyTrend.map(m => ({ month: m.month, paid: m.paid, pending: m.pending })),
      by_method: Object.entries(payMethods).map(([method, amount]) => ({ method, amount, pct: totActual > 0 ? parseFloat((amount / totActual * 100).toFixed(1)) : 0 })).sort((a, b) => b.amount - a.amount),
      by_category: expenseDist,
      paid_vs_pending_by_cat: budgetCats.slice(0, 6).map(c => ({ category: c.category, paid: c.paid, pending: Math.max(c.required - c.paid, 0) })),
      alerts: alerts.slice(0, 5),
      log: expenses.map(r => ({
        date: r.date, category: r.budget_category || r.sub || 'Other', project: r.project,
        vendor: r.supplier || r.merchant, amount: r.amount, method: r.method,
        status: r.paid_by ? 'Paid' : 'Scheduled', comments: r.notes || r.item,
      })).sort((a, b) => (a.date < b.date ? 1 : -1)),
    },

    // ── PAGE 5: COST ANALYSIS ────────────────────────────────
    cost: {
      kpis: [
        { label: 'TOTAL ACTUAL SPEND',   value: totActual, fmt: 'currency' },
        { label: 'HIGHEST COST CATEGORY', value: budgetCats[0] ? budgetCats[0].category : '—', fmt: 'text', note: budgetCats[0] && totActual > 0 ? pct(budgetCats[0].actual / totActual) + '% of Total Spend' : '' },
        { label: 'AVG MONTHLY SPEND',    value: monthlyTrend.length > 0 ? Math.round(totActual / monthlyTrend.length) : 0, fmt: 'currency' },
        { label: 'BUDGET VARIANCE',      value: totActual - totBudget, fmt: 'currency' },
        { label: 'OVER BUDGET ITEMS',    value: budgetCats.filter(c => c.budget > 0 && c.actual > c.budget).length, fmt: 'number', note: 'Items' },
      ],
      top10,
      by_cost_center: Object.entries(costCenters).map(([center, spend]) => ({ center, spend })).sort((a, b) => b.spend - a.spend).slice(0, 8),
      spend_trend: monthlyTrend.map(m => ({ month: m.month, spend: m.actual })),
      heatmap: { categories: topCats, months: heatMonths, data: heatmap },
      pareto,
      actual_vs_budget: budgetCats.slice(0, 8).map(c => ({ category: c.category, actual: c.actual, budget: c.budget, variance: c.actual - c.budget })),
      spend_distribution: budgetCats.slice(0, 8).map(c => ({ center: c.category, amount: c.actual, pct: totActual > 0 ? parseFloat((c.actual / totActual * 100).toFixed(1)) : 0 })),
      details: costDetails,
      insights: [
        budgetCats[0] ? (budgetCats[0].category + ' is the top spend category, representing ' + (totActual > 0 ? pct(budgetCats[0].actual / totActual) : 0) + '% of total spend.') : '',
        budgetCats.filter(c => c.budget > 0 && c.actual > c.budget).length + ' categories are over budget with total variance of ' + fmtM_(Math.abs(overBudget)) + ' EGP.',
      ].filter(Boolean),
    },

    // ── PAGE 6: CASH FLOW ─────────────────────────────────────
    cashflow: {
      kpis: [
        { label: 'TOTAL TRANSFERS IN',   value: Math.round(totalTransfersIn), fmt: 'currency' },
        { label: 'FORECAST CASH OUT (6M PLAN)', value: Math.round(forecastCashOut), fmt: 'currency' },
        { label: 'REMAINING BUDGET (PLAN)', value: Math.round(cashFlowPlanTotal), fmt: 'currency' },
        { label: 'PAYMENTS DUE ≤30 DAYS', value: upcomingPayments.reduce((s2, r) => s2 + r.amount, 0), fmt: 'currency' },
      ],
      forecast_6m: cf6m,
      cash_in_total: Math.round(totalTransfersIn),
      cash_out_by_category: cashOutByCat,
      upcoming_payments: upcomingPayments,
      transfers_log: transfers,
      insights: cf6m.length ? [
        'Cash Flow plan covers ' + cf6m.length + ' periods totaling ' + fmtM_(forecastCashOut) + ' EGP planned cash out.',
        upcomingPayments.length + ' payments due within 30 days totaling ' + fmtM_(upcomingPayments.reduce((s2, r) => s2 + r.amount, 0)) + ' EGP.',
      ] : ['No Cash Flow forecast rows found in the source sheet.'],
    },

    // ── PAGE 7: RISK & ALERTS — confirmed no register source ──
    risks: {
      no_risk_register: true,
      message: 'No Risk Register source sheet found yet (verified across all 3 connected spreadsheets). Alerts below are real and computed from budget/expense data; the Risk Register table needs a dedicated source sheet (risk id, title, project, category, severity, likelihood, impact, status, owner).',
      kpis: [
        { label: 'OPEN ALERTS', value: alerts.length, fmt: 'number' },
        { label: 'CRITICAL ALERTS', value: alerts.filter(a => a.severity === 'Critical').length, fmt: 'number' },
      ],
      register: [],
      alerts,
      by_severity: (() => { const m = {}; alerts.forEach(a => { m[a.severity] = (m[a.severity] || 0) + 1; }); return Object.entries(m).map(([severity, count]) => ({ severity, count })); })(),
    },

    // ── PAGE 8: VENDOR & PROCUREMENT ─────────────────────────
    // Adds real equipment operational status (Active/Inactive/Off-Hire)
    // as an honest substitute for fabricated contract/performance ratings.
    vendors: {
      kpis: [
        { label: 'TOTAL VENDORS (FROM EXPENSES)', value: Object.keys(vMap).length, fmt: 'number' },
        { label: 'REGISTERED CONTRACTORS', value: contractors.length, fmt: 'number' },
        { label: 'TOTAL SPEND', value: topVendors.reduce((s2, v) => s2 + v.commitments, 0), fmt: 'currency' },
        { label: 'ACTIVE EQUIPMENT UNITS', value: eqStatusCounts['Active'] || 0, fmt: 'number', note: eqMaster.length + ' total units' },
      ],
      spend_by_category: expenseDist.slice(0, 6).map(d => ({ category: d.category, amount: d.amount })),
      top_vendors: topVendors,
      contractors_master: contractors,
      equipment_master: eqMaster,
      equipment_status_summary: Object.entries(eqStatusCounts).map(([status, count]) => ({ status, count })),
      no_contract_status: true,
      message_contracts: 'No vendor contract-expiry / performance-rating source sheet found yet. Equipment operational status (Active/Inactive/Off-Hire) is shown above as a real, available signal — it reflects equipment availability, not vendor contract terms.',
    },

    // ── PAGE 9: APPROVAL WORKFLOW — confirmed no source ───────
    approvals: {
      no_data: true,
      message: 'No Approval Workflow source sheet found yet (verified across all 3 connected spreadsheets). Add a sheet with request id, type, project, requester, approver, status, submitted date, decision date to populate this page.',
      kpis: [], by_status: {}, by_type: [], top_approvers: [], by_project: [], bottlenecks: [],
    },

    // ── PAGE 10: MONTHLY PERFORMANCE ──────────────────────────
    // Schedule % can now be partially derived from real Gantt data;
    // Cost/Scope/Quality scores still require a dedicated source.
    performance: {
      no_score_source: !ganttFound,
      message: ganttFound
        ? 'Schedule completion % below is computed from real Gantt Chart data. Cost/Scope/Quality scores require a dedicated tracking sheet — not shown.'
        : 'Schedule/Cost/Scope/Quality performance scores require a dedicated tracking sheet. Financial summary below is real.',
      kpis: [
        { label: 'TOTAL PROJECTS', value: projects.length, fmt: 'number' },
        { label: 'TOTAL SPEND', value: totActual, fmt: 'currency' },
        { label: 'BUDGET UTILIZATION', value: pct(util), fmt: 'percent' },
      ].concat(ganttFound ? [{ label: 'SCHEDULE COMPLETION (REAL)', value: tlKpis.overallComplete, fmt: 'percent', note: 'From Gantt Chart' }] : []),
      financial_summary: {
        total_budget: totBudget, actual_spend: totActual,
        variance: totActual - totBudget,
        variance_pct: totBudget > 0 ? pct((totActual - totBudget) / totBudget) : 0,
        paid_to_date: totPaid, pending_payments: totPending,
      },
      by_project: projects.map(p => {
        const pb = budget.filter(b => b.project === p);
        const pe = expenses.filter(e => e.project === p);
        const pBud = pb.reduce((s2, r) => s2 + r.budget, 0);
        const pAct = pe.reduce((s2, r) => s2 + r.amount, 0);
        return { project: p, budget: pBud, actual: pAct, util_pct: pBud > 0 ? pct(pAct / pBud) : 0 };
      }),
      top5: [],
    },

    // ── PAGE 11: PRODUCTION / LOTS — NOW REAL ─────────────────
    production: {
      kpis: [
        { label: 'TOTAL LOTS', value: lots.length, fmt: 'number' },
        { label: 'TOTAL TONS', value: lots.reduce((a, r) => a + r.qty_ton, 0), fmt: 'number' },
        { label: 'AVG Fe%', value: lots.length > 0 ? parseFloat((lots.reduce((a, r) => a + r.avg_fe, 0) / lots.length).toFixed(2)) : 0, fmt: 'number' },
        { label: 'ACTIVE MINES (LOTS)', value: new Set(lots.map(r => r.mine)).size, fmt: 'number' },
      ],
      empty: lots.length === 0,
      message: lots.length === 0 ? 'Lots sheet in AIT_Supply_chain is currently empty. This page will populate automatically once lot records are added.' : '',
      lots,
      by_mine: byMine,
      equipment_hrs: Object.values(eqHours),
      mines_registered: mines.length,
      material_types: allMaterialTypes,
      mine_material_map: mineToMaterial,
    },

    // ── PAGE 12: QUALITY / SAMPLES ─────────────────────────────
    quality: (() => {
      // ── Per-material Fe% acceptance thresholds (Pass/Reject) ──
      // These are NOT generic industry bands — they are the exact
      // cutoffs supplied by the user for this operation:
      //   Hematite  → Pass if Fe% ≥ 55, else Reject
      //   Limonite  → Pass if Fe% ≥ 55, else Reject
      //   Magnetite → Pass if Fe% ≥ 37, else Reject
      // samples already have .material, .grade, .threshold attached at
      // outer scope above — no need to recompute inside this IIFE.
      const gradedSamples = samples.filter(r => r.Fe > 0);
      const feValues = gradedSamples.map(r => r.Fe);
      const feMin = feValues.length ? Math.min(...feValues) : 0;
      const feMax = feValues.length ? Math.max(...feValues) : 0;
      const feAvg = feValues.length ? feValues.reduce((a, v) => a + v, 0) / feValues.length : 0;

      const passCount = gradedSamples.filter(r => r.grade === 'pass').length;
      const rejectCount = gradedSamples.filter(r => r.grade === 'reject').length;
      const ungradedCount = gradedSamples.filter(r => r.grade === 'ungraded').length;
      const gradedTotal = passCount + rejectCount;
      const passRatePct = gradedTotal ? (passCount / gradedTotal * 100) : 0;

      // Trend: compare first half vs second half of the dated sample history
      const sortedByDate = [...samples].filter(r => r.date).sort((a, b) => a.date.localeCompare(b.date));
      let feTrendNote = '';
      if (sortedByDate.length >= 4) {
        const half = Math.floor(sortedByDate.length / 2);
        const firstHalf = sortedByDate.slice(0, half).map(r => r.Fe).filter(v => v > 0);
        const secondHalf = sortedByDate.slice(half).map(r => r.Fe).filter(v => v > 0);
        if (firstHalf.length && secondHalf.length) {
          const avg1 = firstHalf.reduce((a, v) => a + v, 0) / firstHalf.length;
          const avg2 = secondHalf.reduce((a, v) => a + v, 0) / secondHalf.length;
          const diff = avg2 - avg1;
          feTrendNote = (diff >= 0 ? '+' : '') + diff.toFixed(1) + ' vs earlier samples';
        }
      }

      // Most recent sample date (real, for "data freshness" KPI)
      const latestDate = sortedByDate.length ? sortedByDate[sortedByDate.length - 1].date : '—';
      const daysSinceLatest = latestDate !== '—' ? Math.floor((new Date() - new Date(latestDate)) / 86400000) : null;

      // Batches and mines actually represented
      const uniqueBatches = new Set(samples.map(r => r.batch)).size;
      const uniqueMines = new Set(samples.map(r => r.mine)).size;

      // Pass-rate breakdown per material, since each has its own threshold
      const passRateByMaterial = (() => {
        const m = {};
        gradedSamples.forEach(r => {
          const mat = r.material || 'Unknown';
          if (!m[mat]) m[mat] = { material: mat, pass: 0, reject: 0, ungraded: 0, threshold: r.threshold };
          m[mat][r.grade === 'pass' ? 'pass' : r.grade === 'reject' ? 'reject' : 'ungraded']++;
        });
        return Object.values(m);
      })();

      return {
        kpis: [
          { label: 'TOTAL SAMPLES',  value: samples.length, fmt: 'number', color: 'blue',   note: uniqueBatches + ' batches' },
          { label: 'AVG Fe%',        value: parseFloat(feAvg.toFixed(2)), fmt: 'number', color: 'orange', note: feTrendNote },
          { label: 'Fe% RANGE',      value: feMin.toFixed(1) + ' – ' + feMax.toFixed(1), fmt: 'text', color: 'purple', note: 'Min – Max recorded' },
          { label: 'PASS RATE',      value: parseFloat(passRatePct.toFixed(1)), fmt: 'percent', color: passRatePct >= 60 ? 'green' : passRatePct >= 40 ? 'orange' : 'red', note: passCount + ' of ' + gradedTotal + ' graded samples' },
          { label: 'PASSED',         value: passCount, fmt: 'number', color: 'green', note: gradedTotal ? (passCount / gradedTotal * 100).toFixed(1) + '% of graded' : '' },
          { label: 'REJECTED',       value: rejectCount, fmt: 'number', color: 'red', note: gradedTotal ? (rejectCount / gradedTotal * 100).toFixed(1) + '% of graded' : '' },
          { label: 'MINES SAMPLED',  value: uniqueMines, fmt: 'number', color: 'blue', note: mines.length + ' registered' },
          { label: 'LATEST SAMPLE',  value: latestDate, fmt: 'text', color: daysSinceLatest !== null && daysSinceLatest > 14 ? 'red' : 'green', note: daysSinceLatest !== null ? daysSinceLatest + ' days ago' : '' },
        ],
        samples: gradedSamples,
        by_mine: samplesByMine,
        material_types: allMaterialTypes,
        mine_material_map: mineToMaterial,
        available_elements: availableElements,
        element_trend: elementTrendByDate,
        fe_thresholds: FE_THRESHOLD_MAP,
        pass_reject: { pass: passCount, reject: rejectCount, ungraded: ungradedCount },
        pass_rate_by_material: passRateByMaterial,
        fe_stats: { min: feMin, max: feMax, avg: parseFloat(feAvg.toFixed(2)) },
      };
    })(),

    // ── PAGE 13: MINES MAP ──────────────────────────────────────
    mines: {
      kpis: [
        { label: 'REGISTERED MINES', value: mines.length, fmt: 'number' },
        { label: 'TOTAL QTY (TON/MONTH)', value: mines.reduce((a, r) => a + r.qty_ton, 0), fmt: 'number' },
      ],
      list: mines,
    },

    meta: { budgetModel },
    lastUpdated: Utilities.formatDate(new Date(), TZ(), 'dd/MM/yyyy HH:mm'),
    stats: {
      expense_records: expenses.length, budget_lines: budget.length,
      equipment_logs: eqLog.length, mines: mines.length,
      lots: lots.length, samples: samples.length, contractors: contractors.length,
      gantt_tasks: ganttTasks.length,
      total_budget: totBudget, total_actual: totActual,
    },
  };

  // ── APPEND-ONLY sync to fact_samples in Dashboard spreadsheet ──────────
  // Instead of clearing and rewriting (which lost data), we now:
  //   1. Read existing batch keys already in fact_samples
  //   2. Only append rows whose batch is NOT already there
  // This means: old data is never deleted, new samples are added automatically.
  if (writeFacts) {
    try {
      const ssD = SpreadsheetApp.openById(ID_DASHBOARD);
      appendNewSamples_(ssD, samples, elementNames || ELEMENT_NAMES);
      appendNewLots_(ssD, lots);
    } catch(e) {
      Logger.log('fact_* append error (non-fatal): ' + e);
    }
  }

  // Add permissions list to payload (for admin panel in dashboard)
  try {
    const ssD2 = SpreadsheetApp.openById(ID_DASHBOARD);
    payload.permissions = loadPermissionsList_(ssD2);
  } catch(e) { payload.permissions = []; }

  return payload;
}

// Returns all users from Permissions sheet for the admin panel
function loadPermissionsList_(ssD) {
  const sh = ssD.getSheetByName('Permissions');
  if (!sh) return [];
  const data = sh.getDataRange().getValues();
  const PAGES_LIST = ['exec','timeline','budget','expenses','cost','cashflow',
    'risks','vendors','approvals','performance','production','quality','mines'];
  const EMAIL_COL=0,NAME_COL=2,ROLE_COL=3,ACTIVE_COL=4,EXCEL_COL=5,PDF_COL=6,FIRST_PAGE=7;
  const users = [];
  for (let i = 2; i < data.length; i++) {
    const email = String(data[i][EMAIL_COL]||'').trim().toLowerCase();
    if (!email || !email.includes('@')) continue;
    const active = bool_(data[i][ACTIVE_COL]);
    const canExcel = bool_(data[i][EXCEL_COL]);
    const canPdf   = bool_(data[i][PDF_COL]);
    const pages = [];
    PAGES_LIST.forEach((p, idx) => {
      const val = data[i][FIRST_PAGE + idx];
      if (bool_(val)) pages.push(p);
    });
    users.push({ email, name: String(data[i][NAME_COL]||''),
      role: String(data[i][ROLE_COL]||''), active, canExcel, canPdf, pages });
  }
  return users;
}

// ============================================================
// APPEND-ONLY WRITERS — never clear, only add new rows
// ============================================================
function appendNewSamples_(ssD, samples, elementNames) {
  const SHEET = 'fact_samples';
  let sh = ssD.getSheetByName(SHEET);

  // Build header
  const BASE_COLS = ['date','mine','zone','batch','material','material_match','grade','threshold'];
  const allCols   = [...BASE_COLS, ...elementNames];

  // Create sheet with header if it doesn't exist yet
  if (!sh) {
    sh = ssD.insertSheet(SHEET);
    sh.getRange(1, 1, 1, allCols.length).setValues([allCols]);
    sh.getRange(1, 1, 1, allCols.length).setFontWeight('bold').setBackground('#e2e8f0');
  }

  // Read existing rows to build dedup keys: date|mine|batch
  const lastRow = sh.getLastRow();
  const existingKeys = new Set();
  if (lastRow > 1) {
    // cols: 1=date, 2=mine, 4=batch (1-based)
    const existing = sh.getRange(2, 1, lastRow - 1, 5).getValues();
    existing.forEach(r => {
      const key = String(r[0]||'') + '|' + String(r[1]||'') + '|' + String(r[3]||'');
      if (key !== '||') existingKeys.add(key);
    });
  }

  // Filter to only truly new samples (not already in sheet)
  const newRows = samples.filter(r => {
    const key = String(r.date||'') + '|' + String(r.mine||'') + '|' + String(r.batch||'');
    return r.mine && r.batch && !existingKeys.has(key);
  });
  if (newRows.length === 0) {
    Logger.log('fact_samples: no new rows to append');
    return;
  }

  // Build 2D array and append
  const data2d = newRows.map(r =>
    allCols.map(k => (r[k] !== undefined && r[k] !== null) ? r[k] : '')
  );
  sh.getRange(lastRow + 1, 1, data2d.length, allCols.length).setValues(data2d);
  Logger.log('fact_samples: appended ' + data2d.length + ' new rows (total existing: ' + existingKeys.size + ')');
}

function appendNewLots_(ssD, lots) {
  const SHEET = 'fact_lots';
  let sh = ssD.getSheetByName(SHEET);
  const allCols = ['updated','mine','zone','batch','material','material_match','qty_ton','volume','avg_fe'];

  if (!sh) {
    sh = ssD.insertSheet(SHEET);
    sh.getRange(1, 1, 1, allCols.length).setValues([allCols]);
    sh.getRange(1, 1, 1, allCols.length).setFontWeight('bold').setBackground('#e2e8f0');
  }

  const lastRow = sh.getLastRow();
  const existingBatches = new Set();
  if (lastRow > 1) {
    const batchCol = sh.getRange(2, 4, lastRow - 1, 1).getValues();
    batchCol.forEach(r => { if (r[0]) existingBatches.add(String(r[0])); });
  }

  const newRows = lots.filter(r => r.batch && !existingBatches.has(r.batch));
  if (newRows.length === 0) {
    Logger.log('fact_lots: no new rows to append');
    return;
  }

  const data2d = newRows.map(r =>
    allCols.map(k => (r[k] !== undefined && r[k] !== null) ? r[k] : '')
  );
  sh.getRange(lastRow + 1, 1, data2d.length, allCols.length).setValues(data2d);
  Logger.log('fact_lots: appended ' + data2d.length + ' new rows');
}

// ============================================================
// GET / SAVE USERS — for Admin Panel in dashboard
// ============================================================
function getUsersList_() {
  try {
    const ss   = SpreadsheetApp.openById(ID_DASHBOARD);
    const sh   = ss.getSheetByName('Permissions');
    if (!sh) return { error: 'Permissions sheet not found' };

    const data  = sh.getDataRange().getValues();
    const PAGES_LIST = ['exec','timeline','budget','expenses','cost','cashflow',
                        'risks','vendors','approvals','performance','production','quality','mines'];
    const users = [];

    for (let i = 2; i < data.length; i++) {
      const email = String(data[i][0] || '').trim();
      if (!email || email.indexOf('@') === -1) continue;
      const pages = [];
      PAGES_LIST.forEach((p, idx) => {
        const val = data[i][7 + idx];
        if (bool_(val)) pages.push(p);
      });
      users.push({
        email:    email,
        password: String(data[i][1] || ''),
        name:     String(data[i][2] || ''),
        role:     String(data[i][3] || 'viewer'),
        active:   bool_(data[i][4]),
        canExcel: bool_(data[i][5]),
        canPdf:   bool_(data[i][6]),
        pages:    pages,
      });
    }
    return { ok: true, users };
  } catch(e) {
    return { error: e.toString() };
  }
}

function saveUsersList_(usersJson) {
  try {
    const users = JSON.parse(usersJson);
    const ss    = SpreadsheetApp.openById(ID_DASHBOARD);
    let sh      = ss.getSheetByName('Permissions');
    if (!sh) sh = ss.insertSheet('Permissions');

    const PAGES_LIST = ['exec','timeline','budget','expenses','cost','cashflow',
                        'risks','vendors','approvals','performance','production','quality','mines'];
    const PAGE_LABELS = {
      exec:'Executive Summary',timeline:'Project Timeline',budget:'Budget Overview',
      expenses:'Expenses & Payments',cost:'Cost Analysis',cashflow:'Cash Flow Forecast',
      risks:'Risk & Alerts',vendors:'Vendor & Procurement',approvals:'Approval Workflow',
      performance:'Monthly Performance',production:'Production / Lots',
      quality:'Quality / Samples',mines:'Mines Map'
    };

    // Build rows
    const header = ['Email','Password','Name','Role','Active','Excel','PDF',
                    ...PAGES_LIST.map(p => PAGE_LABELS[p])];
    const titleRow = ['AIT Projects Dashboard — User Permissions (auto-saved by Admin Panel)', ...Array(header.length - 1).fill('')];
    const rows = [titleRow,
                  header,
                  ...users.map(u => [
                    u.email, u.password, u.name, u.role,
                    u.active ? 'TRUE' : 'FALSE',
                    u.canExcel ? 'TRUE' : 'FALSE',
                    u.canPdf ? 'TRUE' : 'FALSE',
                    ...PAGES_LIST.map(p => (u.pages||[]).includes(p) ? 'TRUE' : 'FALSE'),
                  ])];

    sh.clearContents();
    sh.getRange(1, 1, rows.length, rows[0].length).setValues(rows);

    // Basic formatting
    sh.getRange(1, 1, 1, rows[0].length).setBackground('#0d1b2a').setFontColor('#fff').setFontWeight('bold');
    sh.getRange(2, 1, 1, rows[0].length).setBackground('#1b2d44').setFontColor('#fd480e').setFontWeight('bold');
    sh.setFrozenRows(2);

    Logger.log('Saved ' + users.length + ' users to Permissions sheet');
    return { ok: true, saved: users.length };
  } catch(e) {
    return { error: e.toString() };
  }
}

// ============================================================
// SETUP PERMISSIONS SHEET
// Run this ONCE to create the Permissions sheet in the Dashboard.
// After running, edit the sheet directly to add/remove users.
// ============================================================
function setupPermissionsSheet() {
  const ss  = SpreadsheetApp.openById(ID_DASHBOARD);
  let sh     = ss.getSheetByName('Permissions');
  if (sh) {
    Logger.log('Permissions sheet already exists — skipping creation.');
  } else {
    sh = ss.insertSheet('Permissions');
    Logger.log('Created Permissions sheet.');
  }

  const PAGES_LIST = [
    'exec','timeline','budget','expenses','cost',
    'cashflow','risks','vendors','approvals','performance',
    'production','quality','mines'
  ];
  const PAGE_LABELS = {
    exec:'Executive Summary', timeline:'Project Timeline', budget:'Budget Overview',
    expenses:'Expenses & Payments', cost:'Cost Analysis', cashflow:'Cash Flow',
    risks:'Risk & Alerts', vendors:'Vendor & Procurement', approvals:'Approval Workflow',
    performance:'Monthly Performance', production:'Production / Lots',
    quality:'Quality / Samples', mines:'Mines Map'
  };

  // ── Row 1: Section headers ──
  const row1 = ['USER INFO','','','','ACCESS','','','PAGES (TRUE = allowed, FALSE = hidden)', ...Array(PAGES_LIST.length - 1).fill('')];
  // ── Row 2: Column headers ──
  const row2 = [
    'Email','Password','Name','Role','Active','Excel','PDF',
    ...PAGES_LIST.map(p => PAGE_LABELS[p])
  ];
  // ── Row 3+: Sample users ──
  const users = [
    // Admin — all pages
    ['admin@company.com','12345678','Admin User','admin','TRUE','TRUE','TRUE',
      ...PAGES_LIST.map(()=>'TRUE')],
    // Finance — budget, expenses, cost, cashflow only
    ['finance@company.com','87654321','Finance Manager','finance','TRUE','TRUE','FALSE',
      'TRUE','FALSE','TRUE','TRUE','TRUE','TRUE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE'],
    // Operations — production, quality, mines only
    ['ops@company.com','2846555','Operations Manager','operations','TRUE','FALSE','FALSE',
      'FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','TRUE','TRUE','TRUE'],
    // Viewer — exec summary only
    ['viewer@company.com','13467928','Read Only User','viewer','TRUE','FALSE','FALSE',
      'TRUE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE','FALSE'],
  ];

  const totalCols = 7 + PAGES_LIST.length;

  sh.clearContents();

  // Write rows
  sh.getRange(1, 1, 1, totalCols).setValues([row1]);
  sh.getRange(2, 1, 1, totalCols).setValues([row2]);
  sh.getRange(3, 1, users.length, totalCols).setValues(users);

  // ── Formatting ──
  // Row 1 — section header
  sh.getRange(1, 1, 1, totalCols)
    .setBackground('#0d1b2a').setFontColor('#ffffff')
    .setFontWeight('bold').setFontSize(10);

  // Row 2 — column header
  sh.getRange(2, 1, 1, totalCols)
    .setBackground('#1b2d44').setFontColor('#fd480e')
    .setFontWeight('bold').setFontSize(10);

  // Merge row 1 section headers
  sh.getRange(1,1,1,4).merge().setValue('USER INFO');
  sh.getRange(1,5,1,3).merge().setValue('ACCESS');
  sh.getRange(1,8,1,PAGES_LIST.length).merge().setValue('PAGES (TRUE = allowed, FALSE = hidden)');

  // Color pages columns header alternating
  PAGES_LIST.forEach((p, i) => {
    sh.getRange(2, 8+i).setBackground(i%2===0?'#1b2d44':'#162436');
  });

  // Data rows alternating background
  for (let i=0; i<users.length; i++) {
    sh.getRange(3+i,1,1,totalCols).setBackground(i%2===0?'#0d1117':'#111827');
    sh.getRange(3+i,1,1,totalCols).setFontColor('#e8ecf2');
    // Color TRUE/FALSE cells
    for (let c=4; c<totalCols; c++) {
      const val = users[i][c];
      if (val==='TRUE')  sh.getRange(3+i,c+1).setFontColor('#22c55e').setFontWeight('bold');
      if (val==='FALSE') sh.getRange(3+i,c+1).setFontColor('#ef4444');
    }
  }

  // Column widths
  sh.setColumnWidth(1, 220); // Email
  sh.setColumnWidth(2, 120); // Password
  sh.setColumnWidth(3, 160); // Name
  sh.setColumnWidth(4, 120); // Role
  sh.setColumnWidth(5, 70);  // Active
  sh.setColumnWidth(6, 70);  // Excel
  sh.setColumnWidth(7, 70);  // PDF
  PAGES_LIST.forEach((p,i) => sh.setColumnWidth(8+i, 140));

  sh.setFrozenRows(2);
  sh.setFrozenColumns(3);

  Logger.log('✅ Permissions sheet ready! Edit it to add your users.');
  Logger.log('Columns: Email | Password | Name | Role | Active | Excel | PDF | [13 page columns]');
  Logger.log('Set TRUE/FALSE for each page per user.');
}

// ============================================================
// DATABASE WRITER
// ============================================================
// ============================================================
// SHEET NAMES — exactly 12 sheets (one per dashboard page)
// Named with a number prefix so they sort in page order.
// These are the ONLY sheets written to the dashboard spreadsheet
// for dashboard data (plus the raw fact_* tables kept separately
// for traceability and potential external analysis).
// ============================================================
const PAGE_SHEET_NAMES = {
  exec:        'DB_Executive_Summary',
  timeline:    'DB_Project_Timeline',
  budget:      'DB_Budget_Overview',
  expenses:    'DB_Expenses_Payments',
  cost:        'DB_Cost_Analysis',
  cashflow:    'DB_Cash_Flow_Forecast',
  risks:       'DB_Risk_Alerts',
  vendors:     'DB_Vendor_Procurement',
  approvals:   'DB_Approval_Workflow',
  performance: 'DB_Monthly_Performance',
  production:  'DB_Production_Lots',
  quality:     'DB_Quality_Samples',
  mines:       'DB_Mines_Map',
};

const JSON_CHUNK_SIZE = 45000;

// ============================================================
// wTab — write a plain flat table (for raw fact_* sheets)
// ============================================================
function readDashboardFromDb() {
  // User-facing dashboard requests must never write to sheets.
  // This keeps login/refresh fast and avoids write-permission or quota failures blocking users.
  return syncAll({ writeFacts: false });
}