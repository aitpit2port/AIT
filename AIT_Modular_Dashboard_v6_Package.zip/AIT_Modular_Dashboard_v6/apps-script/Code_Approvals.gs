// AIT Modular Dashboard v6 - approvals page data wrapper
function getApprovalsPage_(payload) {
  return (payload && payload.approvals) ? payload.approvals : { no_data: true, message: 'No approvals data found.' };
}
