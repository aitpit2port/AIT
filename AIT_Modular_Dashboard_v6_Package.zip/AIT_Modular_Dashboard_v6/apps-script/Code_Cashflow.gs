// AIT Modular Dashboard v6 - cashflow page data wrapper
function getCashflowPage_(payload) {
  return (payload && payload.cashflow) ? payload.cashflow : { no_data: true, message: 'No cashflow data found.' };
}
