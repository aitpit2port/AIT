// AIT Modular Dashboard v6 - production page data wrapper
function getProductionPage_(payload) {
  return (payload && payload.production) ? payload.production : { no_data: true, message: 'No production data found.' };
}
