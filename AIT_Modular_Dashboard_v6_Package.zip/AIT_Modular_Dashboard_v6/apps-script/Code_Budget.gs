// AIT Modular Dashboard v6 - budget page data wrapper
function getBudgetPage_(payload) {
  return (payload && payload.budget) ? payload.budget : { no_data: true, message: 'No budget data found.' };
}
