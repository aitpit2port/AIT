// AIT Modular Dashboard v6 - quality page data wrapper
function getQualityPage_(payload) {
  return (payload && payload.quality) ? payload.quality : { no_data: true, message: 'No quality data found.' };
}
