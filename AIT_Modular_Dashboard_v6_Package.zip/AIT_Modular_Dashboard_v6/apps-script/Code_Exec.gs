// AIT Modular Dashboard v6 - exec page data wrapper
function getExecPage_(payload) {
  return (payload && payload.exec) ? payload.exec : { no_data: true, message: 'No exec data found.' };
}
