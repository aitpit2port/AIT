// AIT Modular Dashboard v6 - mines page data wrapper
function getMinesPage_(payload) {
  return (payload && payload.mines) ? payload.mines : { no_data: true, message: 'No mines data found.' };
}
