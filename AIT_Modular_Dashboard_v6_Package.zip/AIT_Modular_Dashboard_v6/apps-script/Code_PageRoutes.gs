
// ============================================================
// PAGE ROUTING HELPERS - Modular v6
// ============================================================
function normalizePageKey_(page) {
  const key = String(page || 'exec').trim().toLowerCase();
  const aliases = {
    executive: 'exec', summary: 'exec', gantt: 'timeline', cash: 'cashflow',
    risk: 'risks', vendor: 'vendors', approval: 'approvals', samples: 'quality', lots: 'production', map: 'mines'
  };
  const p = aliases[key] || key;
  return PAGES.indexOf(p) >= 0 ? p : 'exec';
}
function userCanOpenPage_(perms, page) {
  if (!perms || !perms.active) return false;
  if (String(perms.role || '').toLowerCase() === 'admin') return true;
  const allowed = perms.pages || [];
  return allowed.indexOf(page) >= 0;
}
function getPagePayload_(page, payload) {
  page = normalizePageKey_(page);
  if (page === 'exec') return getExecPage_(payload);
  if (page === 'timeline') return getTimelinePage_(payload);
  if (page === 'budget') return getBudgetPage_(payload);
  if (page === 'expenses') return getExpensesPage_(payload);
  if (page === 'cost') return getCostPage_(payload);
  if (page === 'cashflow') return getCashflowPage_(payload);
  if (page === 'risks') return getRisksPage_(payload);
  if (page === 'vendors') return getVendorsPage_(payload);
  if (page === 'approvals') return getApprovalsPage_(payload);
  if (page === 'performance') return getPerformancePage_(payload);
  if (page === 'production') return getProductionPage_(payload);
  if (page === 'quality') return getQualityPage_(payload);
  if (page === 'mines') return getMinesPage_(payload);
  return payload.exec || {};
}
