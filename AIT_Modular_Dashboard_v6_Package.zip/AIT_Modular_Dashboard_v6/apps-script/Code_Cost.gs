// AIT Modular Dashboard v6 - cost page data wrapper
function getCostPage_(payload) {
  return (payload && payload.cost) ? payload.cost : { no_data: true, message: 'No cost data found.' };
}
