
# AIT Modular Dashboard v6 — خطوات التركيب

## 1) تركيب GitHub Pages
ارفع محتوى مجلد `github-pages` كما هو إلى Repository الخاص بالداشبورد:

- `index.html` هو Shell فقط: sidebar + header + iframe.
- `auth.html` هو صفحة تسجيل الدخول.
- كل صفحة داخل `pages/` مستقلة:
  - `pages/exec.html`
  - `pages/quality.html`
  - `pages/production.html`
  - ... إلخ.
- منطق كل صفحة موجود في:
  - `assets/js/pages/exec.js`
  - `assets/js/pages/quality.js`
  - ... إلخ.

لو حصلت مشكلة في صفحة Quality مثلًا، عدل فقط:
`pages/quality.html` أو `assets/js/pages/quality.js`.

## 2) تركيب Apps Script
عندك طريقتين:

### الطريقة الأسهل
افتح Apps Script واستبدل الكود كله بمحتوى:
`apps-script/AIT_Backend_MODULAR_ALL_IN_ONE_v6.gs`

### الطريقة المنظمة داخل Apps Script
اعمل ملفات بنفس الأسماء:
- `Code_Main.gs`
- `Code_PageRoutes.gs`
- `Code_Exec.gs`
- `Code_Quality.gs`
- `Code_Production.gs`
- ... باقي ملفات الصفحات

ثم انسخ كل ملف من مجلد `apps-script` في ملفه المقابل داخل Apps Script.

## 3) Deploy
من Apps Script:
Deploy > New deployment > Web app

الإعدادات:
- Execute as: Me
- Who has access: Anyone أو Anyone with link حسب إعداداتك

انسخ رابط `/exec` الجديد.

## 4) تحديث رابط API
افتح:
`github-pages/assets/js/config.js`

وضع رابط Web App الجديد هنا:

```js
API_URL: 'YOUR_WEB_APP_EXEC_URL'
```

## 5) اختبار سريع
افتح:
`YOUR_WEB_APP_EXEC_URL?action=ping`

لازم يرجع JSON/JSONP فيه:
`version: v6-modular-pages-2026-06-23`

ثم افتح:
`auth.html`

وسجل دخول بمستخدم موجود في صفحة `Permissions`.

## 6) المسار الجديد للبيانات
كل صفحة تطلب بياناتها وحدها من Apps Script:

`action=page&page=quality`

مثال:
`YOUR_WEB_APP_EXEC_URL?action=page&page=quality&email=USER&password=PASS`

## ملاحظات مهمة
- Google Apps Script يجمع كل ملفات `.gs` في Runtime واحد، لذلك الفصل هنا تنظيمي وآمن للصيانة.
- الواجهة مفصولة فعليًا: كل صفحة HTML/JS مستقلة عن الباقي.
- لو صفحة واحدة فيها خطأ في الرسم أو الجدول، باقي الصفحات لن تتأثر.
