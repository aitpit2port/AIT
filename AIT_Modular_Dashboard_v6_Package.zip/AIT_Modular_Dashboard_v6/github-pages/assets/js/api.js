
(function(){
  const cfg = window.AIT_CONFIG || {};
  window.AIT_API_URL = cfg.API_URL || '';
  window.apiRequest = function(action, params={}, options={}){
    return new Promise((resolve,reject)=>{
      if(!window.AIT_API_URL){ reject(new Error('API_URL_NOT_SET')); return; }
      const cb='aitJsonp_'+Date.now()+'_'+Math.random().toString(36).slice(2);
      const qs=new URLSearchParams(Object.assign({},params,{action:action,callback:cb,t:Date.now()}));
      const sc=document.createElement('script'); let done=false;
      const cleanup=()=>{ if(sc.parentNode) sc.parentNode.removeChild(sc); try{ delete window[cb]; }catch(e){ window[cb]=undefined; } };
      const timeoutMs=Number(options.timeoutMs||45000);
      const timer=setTimeout(()=>{ if(done)return; done=true; cleanup(); reject(new Error('Request timeout after '+Math.round(timeoutMs/1000)+'s')); }, timeoutMs);
      window[cb]=data=>{ if(done)return; done=true; clearTimeout(timer); cleanup(); resolve(data); };
      sc.onerror=()=>{ if(done)return; done=true; clearTimeout(timer); cleanup(); reject(new Error('JSONP load error')); };
      sc.src=window.AIT_API_URL+'?'+qs.toString();
      document.body.appendChild(sc);
    });
  };
})();
