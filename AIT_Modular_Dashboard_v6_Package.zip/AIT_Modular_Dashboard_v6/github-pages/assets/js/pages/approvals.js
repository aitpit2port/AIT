// AIT Modular Dashboard v6 - Approvals page
function renderApprovals(){
  let x=LIVE.approvals||{};
  let rowsData=x.requests||x.items||x.workflow||x.by_status||[];
  let msg=x.message||'No Approval Workflow source sheet found yet. Add request id, type, requester, approver and status to populate this page.';
  return kpis(x.kpis||[])+`<div class="grid g2">${card('Approval Workflow',`<div class="list-row"><div><b>${esc(t('Status'))}</b><div class="muted">${esc(t(msg))}</div></div>${badge(x.no_data?'Pending':'Active')}</div>`)}${card('Approval Status',chartBox('c_appStatus','small'))}</div>${card('Approval Workflow',table([{label:'Type'},{label:'Project'},{label:'Owner'},{label:'Date'},{label:'Status'}],Array.isArray(rowsData)?rowsData.slice(0,60).map(r=>row([r.type||r.request_type||'—',r.project||'—',r.owner||r.approver||r.requester||'—',r.date||r.submitted||r.submitted_date||'—',{html:badge(r.status||'Pending')}])):[]))}`;
}
function chartsApprovals(){
  let x=LIVE.approvals||{}, s=x.by_status||{};
  let labels=[],data=[];
  if(Array.isArray(s)){labels=s.map(r=>r.status||r.label||'—');data=s.map(r=>r.count||r.value||0);}else{labels=Object.keys(s);data=Object.values(s);}
  if(!labels.length){labels=['No data'];data=[1];}
  ch('c_appStatus','doughnut',labels,[{label:'Approvals',data:data,backgroundColor:PAL}]);
}
window.AITPage={render:renderApprovals,charts:chartsApprovals};
