// AIT Modular Dashboard v6 - Production / Lots page
function renderProduction(){
  let x=LIVE.production;
  const lotsF=(x.lots||[]).filter(pass);
  const mines=new Set(lotsF.map(r=>r.mine)).size;
  const totalTon=lotsF.reduce((s,r)=>s+Number(r.qty_ton||0),0);
  const feVals=lotsF.map(r=>Number(r.avg_fe||0)).filter(v=>v>0);
  const avgFe=feVals.length?+(feVals.reduce((a,b)=>a+b,0)/feVals.length).toFixed(1):0;
  const batches=new Set(lotsF.map(r=>r.batch)).size;
  const latest=lotsF.slice(-1)[0];
  const liveKpis=[
    {label:'TOTAL LOTS',    value:lotsF.length,      note:batches+' batches'},
    {label:'TOTAL TONNAGE', value:totalTon,           fmt:'currency', note:'Tons'},
    {label:'AVG FE%',       value:avgFe,              note:'Weighted avg'},
    {label:'MINES ACTIVE',  value:mines,              note:'In filtered view'},
    {label:'LATEST LOT',    value:latest?(latest.updated||latest.date||'—'):'—', note:''},
  ];
  return kpis(liveKpis)+
    `<div class="grid g2">
      ${card('Tonnage by Mine',chartBox('c_prodTons','small'))}
      ${card('Avg Fe% by Mine',chartBox('c_prodFe','small'))}
    </div>
    ${card('Production Lots Log',table(
      [{label:'Date'},{label:'Mine'},{label:'Material'},{label:'Batch'},{label:'Qty (Ton)',num:1},{label:'Avg Fe%',num:1}],
      lotsF.map(r=>row([r.updated||r.date,r.mine,r.material,r.batch,{text:fmt(r.qty_ton),num:1},{text:Number(r.avg_fe||0).toFixed(2),num:1}]))
    ))}`;
}
function chartsProduction(){
  // Recompute from filtered lots so mine filter affects charts
  const lots=(LIVE.production.lots||[]).filter(pass);
  const mineMap={};
  lots.forEach(r=>{
    if(!mineMap[r.mine])mineMap[r.mine]={mine:r.mine,tonSum:0,feSum:0,count:0};
    mineMap[r.mine].tonSum+=Number(r.qty_ton||0);
    mineMap[r.mine].feSum+=Number(r.avg_fe||0);
    mineMap[r.mine].count++;
  });
  const by=Object.values(mineMap).map(m=>({mine:m.mine,qty_ton:m.tonSum,avg_fe:m.count?+(m.feSum/m.count).toFixed(2):0}));
  ch('c_prodTons','bar',by.map(r=>r.mine),[{label:'Qty (Ton)',data:by.map(r=>r.qty_ton),backgroundColor:'#fd480ecc'}]);
  ch('c_prodFe','bar',by.map(r=>r.mine),[{label:'Avg Fe%',data:by.map(r=>r.avg_fe),backgroundColor:'#38bdf8cc'}]);
}
window.AITPage={render:renderProduction,charts:chartsProduction};
