
(function(){
  const META={exec:['Executive Summary','Overview of project financial performance and key indicators','الملخص التنفيذي','نظرة عامة على الأداء المالي ومؤشرات المشروع الرئيسية'],timeline:['Project Timeline / Gantt','Schedule progress, milestones, delay and ownership','الجدول الزمني / جانت','متابعة الجدول الزمني والمعالم والتأخير والمسؤوليات'],budget:['Budget Overview','Budget allocation, actual spend and utilization control','نظرة عامة على الميزانية','توزيع الميزانية والمصروف الفعلي ونسب الاستخدام'],expenses:['Expenses & Payment Plan','Expense log, paid / pending payments and overdue items','المصروفات وخطة السداد','سجل المصروفات والمدفوع والمعلق والمتأخرات'],cost:['Cost Analysis','Cost centers, top spend items and overrun analysis','تحليل التكلفة','مراكز التكلفة وأعلى بنود الصرف وتحليل التجاوزات'],cashflow:['Cash Flow Forecast','Upcoming payments and six-month cash-out forecast','توقعات التدفق النقدي','المدفوعات القادمة وتوقعات الصرف لستة أشهر'],risks:['Risk & Alerts','Active alerts, severity distribution and overdue risks','المخاطر والتنبيهات','التنبيهات النشطة وتوزيع الخطورة والمخاطر المتأخرة'],vendors:['Vendor & Procurement','Vendors, contractors, equipment and procurement indicators','الموردون والمشتريات','الموردون والمقاولون والمعدات ومؤشرات التوريد'],approvals:['Approval Workflow','Requests, approvals and bottlenecks','الموافقات','الطلبات والموافقات ونقاط التعطيل'],performance:['Monthly Performance Report','Monthly financial performance and project status','تقرير الأداء الشهري','الأداء المالي الشهري وحالة المشاريع'],production:['Production / Lots','Lots inventory, mine quantities and quality production view','الإنتاج / اللوطات','مخزون اللوطات وكميات المناجم ومؤشرات الإنتاج'],quality:['Quality / Samples','Sample quality, Fe trend and pass / reject analysis','الجودة / العينات','تحليل العينات واتجاه الحديد والقبول والرفض'],mines:['Mines Map','Registered mines, quantities, materials and ownership data','خريطة المناجم','المناجم المسجلة والكميات والخامات وبيانات الملكية']};
  const ICONS={exec:'OV',timeline:'TL',budget:'BD',expenses:'EX',cost:'CA',cashflow:'CF',risks:'RK',vendors:'VD',approvals:'AP',performance:'PR',production:'PD',quality:'QL',mines:'MP'};
  let LANG=localStorage.getItem('ait_lang')||'en';
  let session=AIT_AUTH.requireSession(); if(!session)return;
  let pages=AIT_AUTH.normalizePages(session.pages); if(!pages.length) pages=['exec'];
  let current=new URLSearchParams(location.search).get('page')||pages[0]; if(!pages.includes(current)) current=pages[0];
  const $=id=>document.getElementById(id);
  function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
  function toast(msg){let el=$('toast');if(!el)return;el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),3500)}
  function applyLang(){document.documentElement.dir='ltr';document.body.classList.toggle('ar',LANG==='ar');$('langBtn').textContent=$('langBtn2').textContent=LANG==='ar'?'EN':'AR';}
  function renderNav(){
    $('nav').innerHTML=pages.map(p=>`<div class="nav-item ${p===current?'active':''}" data-page="${p}"><span class="nav-icon">${ICONS[p]||'PG'}</span><span class="nav-label">${esc(LANG==='ar'?META[p][2]:META[p][0])}</span></div>`).join('')+
      `<div class="nav-item" data-logout="1" style="margin-top:12px;border-top:1px solid #1b2d44"><span class="nav-icon">LO</span><span class="nav-label">${LANG==='ar'?'تسجيل الخروج':'Logout'}</span></div>`;
    $('nav').querySelectorAll('[data-page]').forEach(el=>el.onclick=()=>goPage(el.dataset.page));
    $('nav').querySelector('[data-logout]').onclick=()=>{AIT_AUTH.clearAuthSession();location.href='auth.html'};
  }
  function renderHeader(){
    const m=META[current]||META.exec;
    $('pageTitle').textContent=LANG==='ar'?m[2]:m[0]; $('pageSub').textContent=LANG==='ar'?m[3]:m[1];
    $('eyebrow').textContent=LANG==='ar'?'مركز التحكم التنفيذي':'Executive Control Center';
    $('userPill').textContent=(session.name||session.email)+' • '+(session.role||'viewer');
    $('excelBtn').style.display=session.canExcel?'':'none'; $('pdfBtn').style.display=session.canPdf?'':'none';
  }
  function goPage(p){ current=p; history.replaceState(null,'','?page='+encodeURIComponent(p)); renderNav(); renderHeader(); $('pageFrame').src='pages/'+p+'.html'; }
  $('langBtn').onclick=$('langBtn2').onclick=()=>{LANG=LANG==='ar'?'en':'ar';localStorage.setItem('ait_lang',LANG);applyLang();renderNav();renderHeader();try{$('pageFrame').contentWindow.location.reload()}catch(e){}};
  $('refreshBtn').onclick=$('refreshSide').onclick=()=>{try{$('pageFrame').contentWindow.refreshPage()}catch(e){toast('Unable to refresh page')}};
  $('excelBtn').onclick=()=>{try{$('pageFrame').contentWindow.exportCurrentPageExcel()}catch(e){toast('Unable to export Excel')}};
  $('pdfBtn').onclick=()=>{try{$('pageFrame').contentWindow.exportCurrentPagePDF()}catch(e){toast('Unable to export PDF')}};
  applyLang(); renderNav(); renderHeader(); $('pageFrame').src='pages/'+current+'.html';
})();
