
let LIVE={}, LANG=localStorage.getItem('ait_lang')||'en', CURRENT='', PROJECT='all', FILTERS={}, CHARTS={};
const PAL=['#fd480e','#38bdf8','#22c55e','#a78bfa','#f59e0b','#ef4444','#14b8a6','#f97316','#84cc16','#06b6d4'];
const CHART_FILTER_KEY={};
const META={exec:['Executive Summary','Overview of project financial performance and key indicators','الملخص التنفيذي','نظرة عامة على الأداء المالي ومؤشرات المشروع الرئيسية'],timeline:['Project Timeline / Gantt','Schedule progress, milestones, delay and ownership','الجدول الزمني / جانت','متابعة الجدول الزمني والمعالم والتأخير والمسؤوليات'],budget:['Budget Overview','Budget allocation, actual spend and utilization control','نظرة عامة على الميزانية','توزيع الميزانية والمصروف الفعلي ونسب الاستخدام'],expenses:['Expenses & Payment Plan','Expense log, paid / pending payments and overdue items','المصروفات وخطة السداد','سجل المصروفات والمدفوع والمعلق والمتأخرات'],cost:['Cost Analysis','Cost centers, top spend items and overrun analysis','تحليل التكلفة','مراكز التكلفة وأعلى بنود الصرف وتحليل التجاوزات'],cashflow:['Cash Flow Forecast','Upcoming payments and six-month cash-out forecast','توقعات التدفق النقدي','المدفوعات القادمة وتوقعات الصرف لستة أشهر'],risks:['Risk & Alerts','Active alerts, severity distribution and overdue risks','المخاطر والتنبيهات','التنبيهات النشطة وتوزيع الخطورة والمخاطر المتأخرة'],vendors:['Vendor & Procurement','Vendors, contractors, equipment and procurement indicators','الموردون والمشتريات','الموردون والمقاولون والمعدات ومؤشرات التوريد'],performance:['Monthly Performance Report','Monthly financial performance and project status','تقرير الأداء الشهري','الأداء المالي الشهري وحالة المشاريع'],production:['Production / Lots','Lots inventory, mine quantities and quality production view','الإنتاج / اللوطات','مخزون اللوطات وكميات المناجم ومؤشرات الإنتاج'],quality:['Quality / Samples','Sample quality, Fe trend and pass / reject analysis','الجودة / العينات','تحليل العينات واتجاه الحديد والقبول والرفض'],mines:['Mines Map','Registered mines, quantities, materials and ownership data','خريطة المناجم','المناجم المسجلة والكميات والخامات وبيانات الملكية'],admin:['User Permissions','Manage user access and page permissions','إدارة المستخدمين','إدارة صلاحيات الوصول للصفحات']};
const D={'Executive Control Center':'مركز التحكم التنفيذي','Project / Site':'المشروع / الموقع','All Projects':'كل المشاريع','Refresh Data':'تحديث البيانات','Refresh':'تحديث','Excel':'إكسل','PDF':'PDF','All amounts are in EGP':'كل المبالغ بالجنيه المصري','Data as of':'آخر تحديث','Filters':'الفلاتر','Clear Filters':'مسح الفلاتر','All':'الكل','Status':'الحالة','Category':'البند','Amount':'المبلغ','Actual':'الفعلي','Budget':'الميزانية','Remaining':'المتبقي','Variance':'الفارق','Project':'المشروع','Vendor':'المورد','Date':'التاريخ','Notes':'ملاحظات','Owner':'المسؤول','Start':'البداية','Due':'الاستحقاق','Complete':'الإنجاز','Delay':'التأخير','Priority':'الأولوية','Severity':'الخطورة','Issue':'المشكلة','Type':'النوع','Method':'طريقة الدفع','Payee':'المستفيد','Month':'الشهر','Open':'مفتوح','Overdue':'متأخر','Paid':'مدفوع','Pending':'معلق','Scheduled':'مجدول','Completed':'مكتمل','In Progress':'جارٍ التنفيذ','Delayed':'متأخر','Planned':'مخطط','On Track':'على المسار','At Risk':'تحت المراقبة','Off Track':'خارج المسار','Over Budget':'تجاوز الميزانية','Unbudgeted':'غير مدرج بالميزانية','Critical':'حرج','High':'مرتفع','Medium':'متوسط','Low':'منخفض','Healthy':'سليم','Active':'نشط','Expired':'منتهي','Expiring Soon':'قارب الانتهاء','Total':'الإجمالي','Pass':'مقبول','Reject':'مرفوض','TOTAL BUDGET':'إجمالي الميزانية','ACTUAL SPEND':'المصروف الفعلي','REMAINING BUDGET':'المتبقي من الميزانية','OVER BUDGET':'تجاوز الميزانية','PAID TO DATE':'المدفوع حتى الآن','PENDING PAYMENTS':'مدفوعات معلقة','BUDGET UTILIZATION':'استخدام الميزانية','OVERDUE / ALERTS':'المتأخرات / التنبيهات','TOTAL TASKS':'إجمالي المهام','COMPLETED':'مكتمل','IN PROGRESS':'جارٍ التنفيذ','DELAYED':'متأخر','PLANNED':'مخطط','OVERALL COMPLETION':'نسبة الإنجاز الكلية','BUDGET VARIANCE':'فارق الميزانية','OVER BUDGET ITEMS':'بنود متجاوزة','TOTAL TRANSACTIONS':'إجمالي العمليات','TOTAL BUDGET LINES':'بنود الميزانية','REGISTERED MINES':'المناجم المسجلة','TOTAL QTY (TON/MONTH)':'إجمالي الكمية طن / شهر','Expense Distribution by Category':'توزيع المصروفات حسب البند','Budget vs Actual by Category':'الميزانية مقابل الفعلي حسب البند','Monthly Spending Trend':'اتجاه الصرف الشهري','Paid vs Pending by Month':'المدفوع مقابل المعلق شهريًا','Budget Utilization % by Category':'نسبة استخدام الميزانية حسب البند','Top 5 Vendors by Expenses':'أعلى 5 موردين حسب المصروفات','Top 5 Cost Centers by Expenses':'أعلى 5 مراكز تكلفة حسب المصروفات','Top Alerts & Notifications':'أهم التنبيهات والإشعارات','Project Overall Status':'الحالة العامة للمشروع','Project Timeline (Gantt)':'الجدول الزمني للمشروع (جانت)','Task Details':'تفاصيل المهام','Tasks by Status':'المهام حسب الحالة','Budget Allocation by Category':'توزيع الميزانية حسب البند','Budget Notes & Status':'ملاحظات وحالة الميزانية','Detailed Budget Summary':'ملخص الميزانية التفصيلي','Spend by Category':'الصرف حسب البند','Payment Methods':'طرق الدفع','Expense Log':'سجل المصروفات','Actual vs Budget by Category':'الفعلي مقابل الميزانية حسب البند','Top 10 Spend Items':'أعلى 10 بنود صرف','Spend by Cost Center':'الصرف حسب مركز التكلفة','6-Month Cash Out Forecast':'توقعات الصرف النقدي 6 أشهر','Cash Out by Category':'الصرف النقدي حسب البند','Upcoming Payments':'المدفوعات القادمة','Account Transfers Log':'سجل تحويلات الحساب','Alerts by Severity':'التنبيهات حسب الخطورة','Alerts by Type':'التنبيهات حسب النوع','Active Alerts & Notifications':'التنبيهات والإشعارات النشطة','Top Vendors by Spend':'أعلى الموردين حسب الصرف','Equipment Master':'سجل المعدات','Equipment Status':'حالة المعدات','Budget vs Actual by Project':'الميزانية مقابل الفعلي حسب المشروع','Budget Utilization by Project':'استخدام الميزانية حسب المشروع','Financial Summary':'الملخص المالي','Project Performance':'أداء المشروع','Tons by Mine':'الأطنان حسب المنجم','Avg Fe% by Mine (Lots)':'متوسط الحديد حسب المنجم','Lot Inventory':'مخزون اللوطات','Pass / Reject by Mine':'القبول / الرفض حسب المنجم','Daily Avg Fe% Trend':'اتجاه متوسط الحديد اليومي','Element Levels — By Batch & By Day':'نسب العناصر حسب اللوط واليوم','Full Sample Data — All Mines & Batches':'بيانات العينات الكاملة — كل المناجم واللوطات','Mines Map':'خريطة المناجم','Registered Mines':'المناجم المسجلة','Total Qty':'إجمالي الكمية','Equipment Leasing':'تأجير المعدات','Maintenance':'الصيانة','Tools & Equipment':'الأدوات والمعدات','CAPEX / Setup':'تجهيزات / استثمارات','Site Services':'خدمات الموقع','Management Support':'دعم الإدارة','Equipment Purchasing':'شراء المعدات','Water for Road Preparation':'مياه تجهيز الطريق','Manpower':'عمالة','Security Services':'خدمات أمن','Fixed':'ثابتة','Site Services Management':'إدارة خدمات الموقع','HSE':'السلامة والصحة المهنية','Temporary Staffing':'عمالة مؤقتة','Transportation':'نقل','Utilities':'مرافق','Transport Services':'خدمات النقل','Contractors':'مقاولون','Accommodation':'إقامة','Fuel Expense':'وقود','Other / Unmapped':'أخرى / غير مصنفة','April':'أبريل','May':'مايو','June':'يونيو','July':'يوليو','August':'أغسطس','September':'سبتمبر','October':'أكتوبر','November':'نوفمبر','December':'ديسمبر','January':'يناير','February':'فبراير','March':'مارس'};
function t(x){if(x==null)return '—';let s=String(x);return LANG==='ar'?(D[s]||s):s}function esc(s){return String(s??'—').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}function fmt(v){let n=Number(v)||0,a=Math.abs(n);if(a>=1e9)return(n/1e9).toFixed(2)+'B';if(a>=1e6)return(n/1e6).toFixed(2)+'M';if(a>=1e3)return(n/1e3).toFixed(0)+'K';return n.toLocaleString('en-EG',{maximumFractionDigits:0})}function badge(s){let k=String(s||'').toLowerCase(),c=k.includes('critical')||k.includes('over')||k.includes('reject')||k.includes('delayed')||k.includes('expired')?'red':k.includes('high')||k.includes('risk')||k.includes('pending')||k.includes('overdue')?'orange':k.includes('complete')||k.includes('track')||k.includes('paid')||k.includes('pass')||k.includes('active')?'green':k.includes('medium')?'blue':'purple';return `<span class="badge ${c}">${esc(t(s))}</span>`}
function row(cells){return '<tr>'+cells.map(c=>`<td class="${c&&c.num?'num':''}">${c&&c.html?c.html:esc(t(c&&'text'in Object(c)?c.text:c))}</td>`).join('')+'</tr>'}function table(headers,rows){return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th class="${h.num?'num':''}">${t(h.label||h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')||`<tr><td colspan="${headers.length}" class="muted">${LANG==='ar'?'لا توجد بيانات':'No data'}</td></tr>`}</tbody></table></div>`}function card(title,body){return `<div class="card"><div class="card-head"><h3>${esc(t(title))}</h3></div><div class="card-body">${body}</div></div>`}function chartBox(id,cls=''){return `<div class="chart ${cls}"><canvas id="${id}"></canvas></div>`}function kpis(k){return `<div class="kpis ${k.length>4?'big':''}">${(k||[]).map((x,i)=>`<div class="kpi"><div class="kpi-top"><span class="kpi-ico">${['↗','▣','◈','●','◆','■','▲','✓'][i%8]}</span><span>${esc(t(x.label))}</span></div><div class="kpi-val">${x.fmt==='currency'?fmt(x.value):x.fmt==='percent'?(Number(x.value)||0).toFixed(1)+'%':(typeof x.value==='number'?fmt(x.value):esc(t(x.value)))}</div><div class="kpi-note">${esc(t(x.note||'Live KPI'))}</div></div>`).join('')}</div>`}function bars(items,label,value){let max=Math.max(...(items||[]).map(x=>Number(x[value])||0),1);return `<div class="list">${(items||[]).slice(0,10).map(r=>{let v=Number(r[value])||0;return `<div class="list-row"><div><b>${esc(t(r[label]||r.category||r.name||r.center||'—'))}</b><div class="muted">${fmt(v)} EGP</div></div><div class="bar"><span style="width:${Math.min(v/max*100,100)}%"></span></div></div>`}).join('')}</div>`}

function pass(r){
  if(!r) return false;
  if(PROJECT && PROJECT!=='all' && r.project && String(r.project)!==String(PROJECT)) return false;
  return true;
}
function fp(arr){return (arr||[]).filter(pass)}
function destroyCharts(){Object.values(CHARTS).forEach(c=>{try{c.destroy()}catch(e){}});CHARTS={};}
function rerenderPage(){ if(window.__AIT_RENDER_PAGE__) window.__AIT_RENDER_PAGE__(); }
function ch(id,type,labels,datasets,opts={}){
  let el=document.getElementById(id);
  if(!el||!window.Chart)return;
  labels=(labels||[]).map(t);
  datasets=(datasets||[]).map((d,i)=>({
    ...d,label:t(d.label||''),
    borderColor:d.borderColor||PAL[i%PAL.length],
    backgroundColor:d.backgroundColor||PAL[i%PAL.length]+'cc',
    borderWidth:d.borderWidth||2,tension:.35,borderRadius:8
  }));
  const filterKey=CHART_FILTER_KEY[id];
  CHARTS[id]=new Chart(el,{type,data:{labels,datasets},options:{
    responsive:true,maintainAspectRatio:false,
    plugins:{
      legend:{display:opts.legend??true,labels:{color:'#b8c7df',boxWidth:12,font:{size:11}}},
      tooltip:{backgroundColor:'#07101f',borderColor:'#fd480e',borderWidth:1,titleColor:'#ffb294',bodyColor:'#eef4ff',padding:12}
    },
    scales:(type==='doughnut'||type==='pie')?{}:{
      x:{grid:{color:'rgba(148,163,184,.12)'},ticks:{color:'#9fb0c9',maxRotation:35}},
      y:{grid:{color:'rgba(148,163,184,.12)'},ticks:{color:'#9fb0c9',callback:v=>fmt(v)}}
    },
    onClick:filterKey?(evt,els)=>{
      if(!els.length)return;
      const lbl=labels[els[0].index];
      // Toggle: click same value again → clear filter
      FILTERS[filterKey]=(FILTERS[filterKey]===lbl)?'all':lbl;
      rerenderPage();
    }:undefined,
    onHover:filterKey?(evt,els)=>{ el.style.cursor=els.length?'pointer':'default'; }:undefined,
    ...opts
  }});
}

async function loadPageData(pageKey){
  const session=AIT_AUTH.requireSession(); if(!session) return null;
  CURRENT=pageKey;
  const params={page:pageKey,email:session.email,password:session.password||''};
  let res=await apiRequest('page',params,{timeoutMs:60000}).catch(async err=>{
    // Backward-compatible fallback if old backend has no action=page yet.
    const all=await apiRequest('data',{email:session.email,password:session.password||''},{timeoutMs:70000});
    if(all&&all[pageKey]) return {ok:true,pageKey,data:all[pageKey],lastUpdated:all.lastUpdated,permissions:all.permissions,stats:all.stats,meta:all.meta};
    throw err;
  });
  if(!res || res.error){ throw new Error((res&&res.message)||(res&&res.error)||'Page data error'); }
  const pageData=res.data || res.pageData || res[pageKey] || {};
  LIVE={}; LIVE[pageKey]=pageData; LIVE.lastUpdated=res.lastUpdated; LIVE.stats=res.stats; LIVE.permissions=res.permissions;
  return res;
}
function setPageError(msg){
  const el=document.getElementById('page-content'); if(!el)return;
  el.innerHTML='<div class="error-card"><b>Page Error</b><br>'+esc(msg||'Unknown error')+'</div>';
}
function setPageLoading(msg){
  const el=document.getElementById('page-content'); if(!el)return;
  el.innerHTML='<div class="page-loading"><div><div class="logo">AIT</div><h2>'+esc(t('Loading'))+'</h2><p>'+esc(msg||'Loading page data...')+'</p></div></div>';
}
function initPage(pageKey,renderFn,chartsFn){
  window.__AIT_RENDER_PAGE__=function(){
    destroyCharts();
    const el=document.getElementById('page-content'); if(!el)return;
    try{ el.innerHTML=renderFn(); setTimeout(()=>{try{chartsFn&&chartsFn()}catch(e){console.error(e);}},30); }
    catch(e){ console.error(e); setPageError(e.message||String(e)); }
  };
  setPageLoading('Loading '+pageKey+' data...');
  loadPageData(pageKey).then(()=>window.__AIT_RENDER_PAGE__()).catch(e=>{console.error(e); setPageError(e.message||String(e));});
}
window.refreshPage=function(){
  if(!CURRENT || !window.__AIT_RENDER_PAGE__) return;
  setPageLoading('Refreshing page data...');
  loadPageData(CURRENT).then(()=>window.__AIT_RENDER_PAGE__()).catch(e=>setPageError(e.message||String(e)));
};
window.exportCurrentPagePDF=function(){ window.print(); };
window.exportCurrentPageExcel=function(){
  if(!window.XLSX){ alert('XLSX library is not loaded'); return; }
  const wb=XLSX.utils.book_new();
  const data=LIVE[CURRENT]||{};
  let added=false;
  Object.entries(data).forEach(([key,val])=>{
    if(Array.isArray(val) && val.length && typeof val[0]==='object'){
      const ws=XLSX.utils.json_to_sheet(val); XLSX.utils.book_append_sheet(wb,ws,key.substring(0,31)); added=true;
    }
  });
  if(!added){ const ws=XLSX.utils.json_to_sheet([{page:CURRENT,message:'No flat tables found'}]); XLSX.utils.book_append_sheet(wb,ws,'Data'); }
  XLSX.writeFile(wb,'AIT_'+CURRENT+'.xlsx');
};
