
(function(){
  const $=id=>document.getElementById(id);
  const saved=localStorage.getItem(AIT_AUTH.USER_EMAIL_KEY)||'';
  if(saved) $('loginEmail').value=saved;
  function busy(on,msg){ $('loginBtn').disabled=!!on; $('loginBtn').textContent=on?'Checking...':'Sign In'; $('loginSub').textContent=msg||'Sign in to access your modular dashboard'; if(!on)$('loginError').textContent=''; }
  $('loginForm').addEventListener('submit', async e=>{
    e.preventDefault();
    const email=AIT_AUTH.normalizeEmail($('loginEmail').value), password=String($('loginPass').value||'').trim();
    if(!email){$('loginError').textContent='Enter your email';return;}
    if(!password){$('loginError').textContent='Enter your password';return;}
    busy(true,'Checking email, password and page permissions...');
    try{
      const auth=await apiRequest('checkAuth',{email,password},{timeoutMs:25000});
      if(!auth||auth.error||!auth.active){ $('loginError').textContent=(auth&&auth.message)||'Invalid login or inactive account'; busy(false); return; }
      AIT_AUTH.saveAuthSession(auth,email,password);
      busy(true,'Verified. Opening dashboard...');
      location.href='index.html';
    }catch(err){ console.error(err); $('loginError').textContent='Could not connect to Apps Script Web App. Check deployment URL.'; busy(false); }
  });
})();
