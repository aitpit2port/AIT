// AIT Modular Dashboard v6 configuration
// Replace API_URL after every Apps Script deployment if the /exec URL changes.
window.AIT_CONFIG = {
  API_URL: 'https://script.google.com/macros/s/AKfycbw17eoQz22-WWCbRQOowlSr0zadA2uIORnuX3W3B7WPlK4MmQw0hmsyXj8THQirsphp9Q/exec',
  VERSION: 'v6-modular-pages-2026-06-23'
};
