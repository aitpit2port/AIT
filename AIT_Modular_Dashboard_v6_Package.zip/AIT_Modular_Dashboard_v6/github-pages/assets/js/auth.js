
(function(){
  const USER_SESSION_KEY='ait_dashboard_auth_session_v6';
  const LEGACY_SESSION_KEY='ait_dashboard_auth_session_v2';
  const USER_EMAIL_KEY='ait_dashboard_user_email';
  const ALL_PAGE_KEYS=['exec','timeline','budget','expenses','cost','cashflow','risks','vendors','approvals','performance','production','quality','mines'];
  const aliases={
    'executive summary':'exec','project timeline':'timeline','project timeline / gantt':'timeline','timeline':'timeline','gantt':'timeline',
    'budget overview':'budget','budget':'budget','expenses & payment plan':'expenses','expenses':'expenses','expense':'expenses',
    'cost analysis':'cost','cost':'cost','cash flow forecast':'cashflow','cashflow':'cashflow','cash flow':'cashflow',
    'risk & alerts':'risks','risks':'risks','risk':'risks','vendor & procurement':'vendors','vendors':'vendors','procurement':'vendors',
    'monthly performance':'performance','monthly performance report':'performance','performance':'performance','production / lots':'production','production':'production','lots':'production',
    'quality / samples':'quality','quality':'quality','samples':'quality','mines map':'mines','mines':'mines','approval workflow':'approvals','approvals':'approvals'
  };
  function normalizeEmail(v){ return String(v||'').trim().toLowerCase(); }
  function normalizePages(pages){
    if(!pages) return [];
    if(typeof pages==='string') pages=pages.split(/[|,;]/).map(x=>x.trim()).filter(Boolean);
    if(!Array.isArray(pages)) return [];
    const out=[];
    pages.forEach(x=>{ const raw=String(x||'').trim(); const key=aliases[raw.toLowerCase()]||raw; if(ALL_PAGE_KEYS.includes(key)&&!out.includes(key)) out.push(key); });
    return out;
  }
  function isAdminRole(role){ return String(role||'').toLowerCase()==='admin'; }
  function readAuthSession(){
    try{ let raw=sessionStorage.getItem(USER_SESSION_KEY)||sessionStorage.getItem(LEGACY_SESSION_KEY); return raw?JSON.parse(raw):null; }catch(e){ return null; }
  }
  function saveAuthSession(auth,email,password){
    const role=auth.role||'viewer'; let pages=normalizePages(auth.pages||[]); if(isAdminRole(role)&&!pages.length) pages=ALL_PAGE_KEYS.slice(); if(!pages.length) pages=['exec'];
    const session={email:normalizeEmail(email||auth.email),password:String(password||''),name:auth.name||email,role,active:!!auth.active,pages,canExcel:!!auth.canExcel||isAdminRole(role),canPdf:!!auth.canPdf||isAdminRole(role),savedAt:Date.now()};
    sessionStorage.setItem(USER_SESSION_KEY, JSON.stringify(session)); localStorage.setItem(USER_EMAIL_KEY, session.email); return session;
  }
  function clearAuthSession(){ sessionStorage.removeItem(USER_SESSION_KEY); sessionStorage.removeItem(LEGACY_SESSION_KEY); localStorage.removeItem(USER_EMAIL_KEY); }
  function authUrl(){ return location.pathname.indexOf('/pages/')>=0 ? '../auth.html' : 'auth.html'; }
  function requireSession(){ const s=readAuthSession(); if(!s||!s.active||!s.email){ location.href=authUrl(); return null; } return s; }
  window.AIT_AUTH={USER_SESSION_KEY,USER_EMAIL_KEY,ALL_PAGE_KEYS,normalizeEmail,normalizePages,isAdminRole,readAuthSession,saveAuthSession,clearAuthSession,requireSession,authUrl};
})();
